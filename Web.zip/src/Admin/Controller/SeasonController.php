<?php 
namespace App\Admin\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Admin\Entity\Season;
use MediaBundle\Entity\Media;
use App\Admin\Form\SeasonType;
use App\Admin\Form\EditSeasonType;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use \Liip\ImagineBundle\Imagine\Cache\CacheManager;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;

class SeasonController extends AbstractController
{
     public function api_by_serie(Request $request,$id,$token,CacheManager $imagineCacheManager) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();
        $serie=$em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("type"=>"serie","id"=>$id));
        if ($serie==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $seasons =   $em->getRepository("App\Admin\Entity\Season")->findBy(array("poster"=>$serie),array("position"=>"asc"));
        
        $seasons_list =  array();

        foreach ($seasons as $key => $season) {
            $season_obj = null;
            $season_obj["id"]=$season->getId();
            $season_obj["title"]=$season->getTitle();
            $episodes_list =  array();
            foreach ($season->getEpisodes() as $episode) {
                $episode_obj = null;
                if ($episode->getEnabled()) {
                    
                    $episode_obj["id"] = $episode->getId();
                    $episode_obj["title"] = $episode->getTitle();
                    $episode_obj["description"] = $episode->getDescription();
                    $episode_obj["duration"] = $episode->getDuration();
                    if($episode->getMedia())
                        $episode_obj["image"] = $imagineCacheManager->getBrowserPath($episode->getMedia()->getPath(), 'episode_thumb');

                    $torrent_list =  array();
                    foreach ($episode->getTorrents() as $key => $torrent) {
                        $torrent_obj = array();
                        $torrent_obj["id"]=$torrent->getId();
                        $torrent_obj["title"]=$torrent->getTitle();
                        $torrent_obj["quality"]=$torrent->getQuality();
                        $torrent_obj["size"]=$torrent->getSize();
                        $torrent_obj["leechers"]=$torrent->getLeechers();
                        $torrent_obj["seeders"]=$torrent->getSeeders();
                        $torrent_obj["premium"]=$torrent->getPremium();
                        $torrent_obj["url"]=$torrent->getUrl();
                    
                        $torrent_list[] = $torrent_obj;
                    }

                    $episode_obj["torrents"] = $torrent_list;

                    $episodes_list[]=$episode_obj;
                }
            }
            $season_obj["episodes"] = $episodes_list;
            $seasons_list[]=$season_obj;
        }





        $response = new Response();
        $response->setContent(json_encode(
            $seasons_list
        ));
        $response->headers->set('Content-Type', 'application/json');
        return $response;

    }

    public function edit(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $season=$em->getRepository("App\Admin\Entity\Season")->findOneBy(array("id"=>$id));
        if ($season==null) {
            throw new NotFoundHttpException("Page not found");
        }

        $form = $this->createForm(SeasonType::class,$season);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
                $em->flush();  
                $this->addFlash('success', 'Operation has been done successfully');
                return $this->redirect($this->generateUrl('app_admin_serie_seasons',array("id"=>$season->getPoster()->getId())));
        }
        return $this->render("Admin/Season/edit.html.twig",array("season"=>$season,"form"=>$form->createView()));
    }
    

    public function up(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $season=$em->getRepository("App\Admin\Entity\Season")->find($id);
        if ($season==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $poster=$season->getPoster();

        $rout =  'app_admin_serie_seasons';
        if ($season->getPosition()>1) {
                $p=$season->getPosition();
                $seasons=$em->getRepository('App\Admin\Entity\Season')->findBy(array("poster"=>$poster),array("position"=>"asc"));
                foreach ($seasons as $key => $value) {
                    if ($value->getPosition()==$p-1) {
                        $value->setPosition($p);  
                    }
                }
                $season->setPosition($season->getPosition()-1);
                $em->flush(); 
        }
        return $this->redirect($this->generateUrl($rout,array("id"=>$poster->getId())));

    }
    public function down(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $season=$em->getRepository("App\Admin\Entity\Season")->find($id);
        if ($season==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $poster=$season->getPoster();

        $rout =  'app_admin_serie_seasons';

        $max=0;
        $seasons=$em->getRepository('App\Admin\Entity\Season')->findBy(array("poster"=>$poster),array("position"=>"asc"));
        foreach ($seasons  as $key => $value) {
            $max=$value->getPosition();  
        }
        if ($season->getPosition()<$max) {
            $p=$season->getPosition();
            foreach ($seasons as $key => $value) {
                if ($value->getPosition()==$p+1) {
                    $value->setPosition($p);  
                }
            }
            $season->setPosition($season->getPosition()+1);
            $em->flush();  
        }
        return $this->redirect($this->generateUrl($rout,array("id"=>$poster->getId())));    

    }
    public function delete($id,Request $request) : Response
    {
        $em=$this->getDoctrine()->getManager();

        $season = $em->getRepository("App\Admin\Entity\Season")->find($id);
        if($season==null){
            throw new NotFoundHttpException("Page not found");
        }
        
        $serie=$season->getPoster();

            foreach ($season->getEpisodes() as $key => $episode) {
            
                foreach ($episode->getTorrents() as $key => $torrent) {
                    $em->remove($torrent);
                    $em->flush();

                }
                foreach ($episode->getSubtitles() as $key => $subtitle) {
                    $media_subtitle = $subtitle->getMedia();
                    
                    $em->remove($subtitle);
                    $em->flush();

                    if ($media_subtitle!=null) {
                        $media_subtitle->delete($this->getParameter('files_directory'));
                        $em->remove($media_subtitle);
                        $em->flush();
                    }
                }
                $media_episode = $episode->getMedia();

                $em->remove($episode);
                $em->flush();

                if ($media_episode!=null) {
                    $media_episode->delete($this->getParameter('files_directory'));
                    $em->remove($media_episode);
                    $em->flush();
                }
            }
            $em->remove($season);
            $em->flush();


            $seasons =  $em->getRepository("App\Admin\Entity\Season")->findBy(array("poster"=>$serie),array("position"=>"asc"));
            $position = 0;
            foreach ($seasons as $key => $sea) {
                $position ++;
                $sea->setPosition($position);
                $em->flush();
            }


            $views = 0;
            foreach ($serie->getSeasons() as $key => $season) {
                foreach ($season->getEpisodes() as $key => $value) {
                    $views += $value->getViews();
                }
            }
            $serie->setViews($views);
            $em->flush();

            $this->addFlash('success', 'Operation has been done successfully');
            return $this->redirect($this->generateUrl('app_admin_serie_seasons',array("id"=>$serie->getId())));
        
    }

}
?>