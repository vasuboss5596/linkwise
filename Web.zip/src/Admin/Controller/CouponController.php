<?php 
namespace App\Admin\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Admin\Entity\Coupon;
use App\Media\Entity\Media;
use App\Admin\Form\CouponType;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;

class CouponController extends AbstractController
{
    public function index() : Response
    {
        $em = $this->getDoctrine()->getManager();
        $coupons =   $em->getRepository("App\Admin\Entity\Coupon")->findBy(array());
        return $this->render("Admin/Coupon/index.html.twig",array("coupons"=>$coupons));
    }

    public function api_check(Request $request,$token) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();
        $id = $request->get("code");

        $coupon = $em->getRepository("App\Admin\Entity\Coupon")->findOneBy(array("code"=>$id));
        $settings = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());

        $message = "";
        $code = 200;
        $values =array();
        if ($coupon == null) {
            $message = "Coupon code not found"; 
            $code = 404;   
        }else{
            if ($coupon->getExpired() < new \DateTime() )  {
               $message = "This coupon code has expired.";   
               $code = 403;           
            }else{
                  $obj_id["name"] = "id";
                  $obj_id["value"] = $coupon->getId();

                  $obj_title["name"] = "title";
                  $obj_title["value"] = $coupon->getTitle();

                  $obj_discount["name"] = "discount";
                  $obj_discount["value"] = $coupon->getDiscount();

                  $obj_type["name"] = "type";
                  $obj_type["value"] = $coupon->getType();

                  $obj_code["name"] = "code";
                  $obj_code["value"] = $coupon->getCode();

                  $obj_currency["name"] = "currency";
                  $obj_currency["value"] = $settings->getCurrency();
                  
                  $values[] = $obj_id;
                  $values[] = $obj_title;
                  $values[] = $obj_discount;
                  $values[] = $obj_type;
                  $values[] = $obj_code;
                  $values[] = $obj_currency;
            }  
        } 
        $error=array(
                "code"=>$code,
                "message"=>$message,
                "values"=>$values,
            );

        header('Content-Type: application/json'); 
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($error, 'json');
        return new Response($jsonContent);
    }

    public function add(Request $request) : Response
    {
        $coupon= new Coupon();
        $form = $this->createForm(CouponType::class,$coupon);
        $em=$this->getDoctrine()->getManager();
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()){
            $em->persist($coupon);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
            return $this->redirect($this->generateUrl('app_admin_coupon_index'));
       }
        return $this->render("Admin/Coupon/add.html.twig",array("form"=>$form->createView()));
    }
    public function delete($id,Request $request) : Response
    {
        $em=$this->getDoctrine()->getManager();

        $coupon = $em->getRepository("App\Admin\Entity\Coupon")->find($id);
        if($coupon==null){
            throw new NotFoundHttpException("Page not found");
        }

        $coupons=$em->getRepository('App\Admin\Entity\Coupon')->findBy(array());

        $subscriptions=$em->getRepository('App\Admin\Entity\Subscription')->count(array("coupon"=>$coupon));

        if($subscriptions>0){
            $this->addFlash('warning', 'Some subscriptions already associated to this coupon');
        }else{
            $em->remove($coupon);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');

        }

        return $this->redirect($this->generateUrl('app_admin_coupon_index'));

    }
    public function edit(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $coupon=$em->getRepository("App\Admin\Entity\Coupon")->find($id);
        if ($coupon==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $form = $this->createForm(CouponType::class,$coupon);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
            return $this->redirect($this->generateUrl('app_admin_coupon_index'));
 
        }
        return $this->render("Admin/Coupon/edit.html.twig",array("coupon"=>$coupon,"form"=>$form->createView()));
    }
}
?>