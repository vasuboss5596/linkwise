<?php

namespace App\Admin\Controller;

use App\Admin\Entity\Slide;
use App\Admin\Form\SlideType;
use App\Media\Entity\Media;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\FormError;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
class SlideController extends AbstractController {

	public function index() : Response
	{
		$em = $this->getDoctrine()->getManager();
		$slides = $em->getRepository("App\Admin\Entity\Slide")->findBy(array(), array("position" => "asc"));
		return $this->render("Admin/Slide/index.html.twig", array("slides" => $slides));
	}
	public function api_all() : Response
	{
		$em = $this->getDoctrine()->getManager();
		$slides = $em->getRepository("App\Admin\Entity\Slide")->findBy(array(), array("position" => "asc"));
		$imagineCacheManager = $this->get('liip_imagine.cache.manager');

		return $this->render('Admin/Slide/api_all.html.php', array("slides" => $slides));
	}
	public function up(Request $request, $id) : Response
	{
		$em = $this->getDoctrine()->getManager();
		$slide = $em->getRepository("App\Admin\Entity\Slide")->find($id);
		if ($slide == null) {
			throw new NotFoundHttpException("Page not found");
		}
		if ($slide->getPosition() > 1) {
			$p = $slide->getPosition();
			$slides = $em->getRepository('App\Admin\Entity\Slide')->findAll();
			foreach ($slides as $key => $value) {
				if ($value->getPosition() == $p - 1) {
					$value->setPosition($p);
				}
			}
			$slide->setPosition($slide->getPosition() - 1);
			$em->flush();
		}
		return $this->redirect($this->generateUrl('app_admin_slide_index'));
	}
	public function down(Request $request, $id) : Response
	{
		$em = $this->getDoctrine()->getManager();
		$slide = $em->getRepository("App\Admin\Entity\Slide")->find($id);
		if ($slide == null) {
			throw new NotFoundHttpException("Page not found");
		}
		$max = 0;
		$slides = $em->getRepository('App\Admin\Entity\Slide')->findBy(array(), array("position" => "asc"));
		foreach ($slides as $key => $value) {
			$max = $value->getPosition();
		}
		if ($slide->getPosition() < $max) {
			$p = $slide->getPosition();
			foreach ($slides as $key => $value) {
				if ($value->getPosition() == $p + 1) {
					$value->setPosition($p);
				}
			}
			$slide->setPosition($slide->getPosition() + 1);
			$em->flush();
		}
		return $this->redirect($this->generateUrl('app_admin_slide_index'));
	}
	public function delete($id, Request $request) : Response
	{
		$em = $this->getDoctrine()->getManager();

		$slide = $em->getRepository("App\Admin\Entity\Slide")->find($id);
		if ($slide == null) {
			throw new NotFoundHttpException("Page not found");
		}

			$media_old = $slide->getMedia();
			$em->remove($slide);
			$em->flush();

			if ($media_old != null) {
				$media_old->delete($this->getParameter('files_directory'));
				$em->remove($media_old);
				$em->flush();
			}
			$slides = $em->getRepository('App\Admin\Entity\Slide')->findBy(array(), array("position" => "asc"));

			$p = 1;
			foreach ($slides as $key => $value) {
				$value->setPosition($p);
				$p++;
			}
			$em->flush();
			$this->addFlash('success', 'Operation has been done successfully');
			return $this->redirect($this->generateUrl('app_admin_slide_index'));
		
	}
	public function add(Request $request) : Response
	{
		$em = $this->getDoctrine()->getManager();

		$slide = new Slide();
		$form = $this->createForm(SlideType::class, $slide);
		$form->handleRequest($request);
		if ($form->isSubmitted() && $form->isValid()) {
			if ($slide->getFile() != null) {
				$media = new Media();
				$media->setFile($slide->getFile());
				$media->upload($this->getParameter('files_directory'));

				$em->persist($media);
				$em->flush();
				$slide->setMedia($media);
				$slide->setTitle(base64_encode($slide->getTitle()));
				$max = 0;
				$slides = $em->getRepository('App\Admin\Entity\Slide')->findBy(array(), array("position" => "asc"));
				foreach ($slides as $key => $value) {
					if ($value->getPosition() > $max) {
						$max = $value->getPosition();
					}
				}
				$slide->setPosition($max + 1);
				$em->persist($slide);
				$em->flush();
				$this->addFlash('success', 'Operation has been done successfully');
				return $this->redirect($this->generateUrl('app_admin_slide_index'));
			} else {
				$error = new FormError("Required image file");
				$form->get('file')->addError($error);
			}
		}
		return $this->render('Admin/Slide/add.html.twig', array("form" => $form->createView()));
	}
	public function edit(Request $request, $id) : Response
	{
		$em = $this->getDoctrine()->getManager();
		$slide = $em->getRepository("App\Admin\Entity\Slide")->find($id);
		if ($slide == null) {
			throw new NotFoundHttpException("Page not found");
		}
		$slide->setTitle(base64_decode($slide->getTitle()));
		$form = $this->createForm(SlideType::class, $slide);
		$form->handleRequest($request);
		if ($form->isSubmitted() && $form->isValid()) {
			if ($slide->getFile() != null) {
				$media = new Media();
				$media_old = $slide->getMedia();
				$media->setFile($slide->getFile());
				$media->upload($this->getParameter('files_directory'));
				$em->persist($media);
				$em->flush();
				$slide->setMedia($media);
				$em->flush();
				$media_old->delete($this->getParameter('files_directory'));
				$em->remove($media_old);
				$em->flush();
			}

			$slide->setTitle(base64_encode($slide->getTitle()));


			$em->persist($slide);
			$em->flush();

			$this->addFlash('success', 'Operation has been done successfully');
			return $this->redirect($this->generateUrl('app_admin_slide_index'));

		}
		return $this->render("Admin/Slide/edit.html.twig", array("form" => $form->createView()));
	}
}
?>