<?php

namespace App\Admin\Controller;
use App\Admin\Entity\Comment;
use App\Admin\Entity\Device;
use App\Admin\Entity\Item;

use App\Media\Entity\Media;
use App\Admin\Form\SettingType;
use App\Admin\Form\ConditionsType;

use App\Admin\Form\AdsType;
use App\Admin\Form\WebAdsType;
use App\Admin\Form\PaymentType;
use App\Admin\Form\FaqType;
use App\Admin\Form\RefundType;
use App\Admin\Form\PolicyType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class SettingController extends AbstractController
{

    


    public function faq(Request $request) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());
        $form = $this->createForm(FaqType::class, $setting);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($setting);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
        }
        return $this->render("Admin/Setting/faq.html.twig", array("setting" => $setting, "form" => $form->createView()));
    } 
    public function refundpolicy(Request $request) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());
        $form = $this->createForm(RefundType::class, $setting);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($setting);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
        }
        return $this->render("Admin/Setting/refund_policy.html.twig", array("setting" => $setting,"form" => $form->createView()));
    }


    public function conditions(Request $request) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());
        $form = $this->createForm(ConditionsType::class, $setting);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($setting);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
        }
        return $this->render("Admin/Setting/conditions.html.twig", array("setting" => $setting, "form" => $form->createView()));
    } 
    public function privacypolicy(Request $request) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());
        $form = $this->createForm(PolicyType::class, $setting);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($setting);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
        }
        return $this->render("Admin/Setting/privacy_policy.html.twig", array("setting" => $setting, "form" => $form->createView()));
    } 
    public function payment(Request $request) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());
        $form = $this->createForm(PaymentType::class, $setting);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($setting);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
        }
        return $this->render("Admin/Setting/payment.html.twig", array("setting" => $setting, "form" => $form->createView()));
    } 

    public function ads(Request $request) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());
        $form = $this->createForm(AdsType::class, $setting);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($setting);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
        }
        return $this->render("Admin/Setting/ads.html.twig", array("setting" => $setting, "form" => $form->createView()));
    } 

    public function app(Request $request) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());
        $form = $this->createForm(SettingType::class, $setting);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            if ($setting->getFile() != null) {
                $media = $setting->getMedia();
                $media->setFile($setting->getFile());
                $media->delete($this->getParameter('files_directory'));
                $media->upload($this->getParameter('files_directory'));
                $em->persist($media);
                $em->flush();
            }
            $em->persist($setting);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
        }
        return $this->render("Admin/Setting/app.html.twig", array("setting" => $setting, "form" => $form->createView()));
    } 



    



}