<?php
namespace App\Admin\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Admin\Form\AdminAddType;
use App\Admin\Form\AdminEditType;
use App\Admin\Form\AdminPasswordType;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use App\Media\Entity\Media;
use App\Auth\Entity\User;

class AdminController  extends AbstractController
{  
    
    public function index(PaginatorInterface $paginator, Request $request): Response
    {
        $em = $this->getDoctrine()->getManager();
        
        $repository = $em->getRepository(User::class);
        
        $query_builder = $repository->createQueryBuilder('u')
            ->where('u.roles like :role')
            ->setParameter('role', '%ADMIN%');

        if ($request->query->get("q")) {
            $query_builder->andWhere("u.name like :q or u.email like :q");
            $query_builder->setParameter("q","%".$request->query->get("q")."%");
        }
        $query = $query_builder->getQuery();
        $pagination = $paginator->paginate(
            $query, 
            $request->query->getInt('page', 1), 
            10
        );

        return $this->render('Admin/Admin/index.html.twig', ['pagination' => $pagination]);
    }
    public function add(Request $request,UserPasswordEncoderInterface $passwordEncoder,UserPasswordHasherInterface $userPasswordHasher): Response
    {

        $em = $this->getDoctrine()->getManager();

        
        $form = $this->createForm(AdminAddType::class,[]);
        $form->handleRequest($request);
        if($form->isSubmitted()){
            $valide =  true;
            if(!$form->isValid()){
                $valide = false;
            }
            $user =  $em->getRepository(User::class)->findOneBy(["email"=>$form->get("email")->getData()]);
            if ($user != null) {
                $valide = false;
                $form->get('email')->addError(new FormError('Email address is already in use by another account'));

            }
            if ($valide) {
                $media_user= new Media();
                if ($form->get("file")->getData() == null) {
                        $file_name = md5(uniqid());
                        $file_name =  $file_name.".jpeg";
                        if (!file_exists($this->getParameter('files_directory')."jpg/")) {
                            mkdir($this->getParameter('files_directory')."jpg/");
                        }
                        copy($this->getParameter('files_directory')."/../admin/img/profile.jpg", $this->getParameter('files_directory')."jpg/".$file_name);
                        sleep(1);
                        $media_user->setTitre("profile.jpg");                  
                        $media_user->setUrl($file_name);                    
                        $media_user->setType("image/jpg");                 
                        $media_user->setExtension("jpg");                  
                        $media_user->setEnabled(true);
                        $em->persist($media_user);
                        $em->flush();
                }else{
                    $media_user= new Media();
                    $media_user->setFile($form->get('file')->getData());
                    $media_user->upload($this->getParameter('files_directory'));
                    $em->persist($media_user);
                    $em->flush();
                    $media_user->setFile(null);
                }

                $user = new User();
                $user->setName($form->get("name")->getData());
                $user->setEmail($form->get("email")->getData());
                $user->setEnabled($form->get("enabled")->getData());
                $user->setIsVerified(true);
                $user->setMedia($media_user);
                $user->addRole("ROLE_ADMIN");

                $encodedPassword = $userPasswordHasher->hashPassword(
                    $user,
                    $form->get('plainPassword')->getData()
                );

                $user->setPassword($encodedPassword);
                $em->persist($user);
                $em->flush();
                $this->addFlash('success','Admin has been created successfully !');
                return $this->redirectToRoute('app_admin_admin_index');

            }

        }
        return $this->render('Admin/Admin/add.html.twig', ['form' => $form->createView()]);

    }
    public function password($id,Request $request,UserPasswordEncoderInterface $passwordEncoder,UserPasswordHasherInterface $userPasswordHasher): Response
    {
        $em = $this->getDoctrine()->getManager();
        $user =  $em->getRepository(User::class)->find($id);
        if ($user == null) {
            throw new NotFoundHttpException();
        }
        $form = $this->createForm(AdminPasswordType::class,[]);
        $form->handleRequest($request);
        if($form->isSubmitted() &&  $form->isValid()){

                $encodedPassword = $userPasswordHasher->hashPassword(
                    $user,
                    $form->get('plainPassword')->getData()
                );

                $user->setPassword($encodedPassword);
                $em->flush();

            $this->addFlash('success','Admin password has been resetted successfully !');
            return $this->redirectToRoute('app_admin_admin_index');

        }
        return $this->render('Admin/Admin/password.html.twig', ["user"=>$user,'form' => $form->createView()]);
        
    }
    public function edit($id,Request $request): Response
    {
        $em = $this->getDoctrine()->getManager();
        $user =  $em->getRepository(User::class)->find($id);
        if ($user == null) {
            throw new NotFoundHttpException();
        }
        $form = $this->createForm(AdminEditType::class,["name"=>$user->getName(),"email"=>$user->getEmail(),"enabled"=>$user->isEnabled()]);
        $form->handleRequest($request);
        if($form->isSubmitted()){
            $valide =  true;
            if(!$form->isValid()){
                $valide = false;
            }
            $user_check =  $em->getRepository(User::class)->findOneBy(["email"=>$form->get("email")->getData()]);
            if ($user_check != null && $user->getEmail() != $user_check->getEmail()) {
                $valide = false;
                $form->get('email')->addError(new FormError('Email address is already in use by another account'));
            }
            if ($valide) {
                $media_user= new Media();
                if ($form->get("file")->getData() != null) {

                    $media_old_user = $user->getMedia();
                    $media_user= new Media();
                    $media_user->setFile($form->get('file')->getData());
                    $media_user->upload($this->getParameter('files_directory'));
                    $em->persist($media_user);
                    $em->flush();
                    $media_user->setFile(null);
                    $user->setMedia($media_user);


                    if ($media_old_user != null) {
                        $media_old_user->delete($this->getParameter('files_directory'));
                        $em->remove($media_old_user);
                        $em->flush();
                    }

                }

                $user->setName($form->get("name")->getData());
                $user->setEmail($form->get("email")->getData());
                $user->setEnabled($form->get("enabled")->getData());


                $em->flush();
                $this->addFlash('success','Admin has been edited successfully !');
                return $this->redirectToRoute('app_admin_admin_index');

            }

        }
        return $this->render('Admin/Admin/edit.html.twig', ['form' => $form->createView()]);
        
    }
    public function delete($id): Response
    {
        $em = $this->getDoctrine()->getManager();
        $user =  $em->getRepository(User::class)->find($id);
        if ($user == null) {
            throw new NotFoundHttpException();
        }

        $media_user = $user->getMedia();

        if ($media_user != null) {
            $media_user->delete($this->getParameter('files_directory'));
            $em->remove($media_user);
            $em->flush();
        }

        $em->remove($user);
        $em->flush();
        $this->addFlash('success','Admin has been deleted successfully !');
        return $this->redirectToRoute('app_admin_admin_index');
    
    }
}





