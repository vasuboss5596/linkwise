<?php

namespace App\Admin\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Admin\Entity\Comment;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\HttpFoundation\Response;
use Knp\Component\Pager\PaginatorInterface;
use \Liip\ImagineBundle\Imagine\Cache\CacheManager;
use Knp\Bundle\TimeBundle\DateTimeFormatter;


class CommentController extends AbstractController
{
    public function index(Request $request,PaginatorInterface $paginator) : Response
    {

        $em = $this->getDoctrine()->getManager();


        $dql        = "SELECT c FROM App\Admin\Entity\Comment c ORDER BY c.created desc";
        $query      = $em->createQuery($dql);
        $pagination = $paginator->paginate(
        $query,
        $request->query->getInt('page', 1),
            10
        );
        $count=$em->getRepository('App\Admin\Entity\Comment')->count(array());
        
        return $this->render('Admin/Comment/index.html.twig',
            array(
                'pagination' => $pagination,
                'count' => $count,
            )
        );
    }
    public function api_by_poster($id,$token,CacheManager $imagineCacheManager,DateTimeFormatter $dateTimeFormatter) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();

        $poster=$em->getRepository('App\Admin\Entity\Poster')->find($id);
        $comments=array();
        if ($poster!=null) {
            $comments=$em->getRepository('App\Admin\Entity\Comment')->findBy(array("poster"=>$poster));
        }

        $list=array();
        foreach ($comments as $key => $comment) {
            $a["id"]=$comment->getId();
            $a["user"]=$comment->getUser()->getName();
            $a["content"]=$comment->getContent();
            $a["enabled"]=$comment->getEnabled();
            $a["image"] = $imagineCacheManager->getBrowserPath($comment->getUser()->getMedia()->getPath(), 'thumb_square_100') ;
              
            $now = new \DateTime();
            $a["created"]= $dateTimeFormatter->formatDiff($comment->getCreated(),$now);
            $list[]=$a;
        }
        header('Content-Type: application/json'); 
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($list, 'json');
        return new Response($jsonContent);
    }
    public function api_add(Request $request,$token,CacheManager $imagineCacheManager) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }

        $user=$request->get("user");
        $comment=$request->get("comment");
        $id=$request->get("id");
        $key=$request->get("key");

        $em=$this->getDoctrine()->getManager();
        $user_obj=$em->getRepository("App\Auth\Entity\User")->find($user);
        $poster_obj=$em->getRepository('App\Admin\Entity\Poster')->find($id);



        $code = "200";
        $message = "";
        $errors = array();
        if ($user_obj != null and $poster_obj != null) {
            if (sha1($user_obj->getPassword()) == $key and $user_obj->isEnabled()) {
                $code="200";
                $message="";
                $errors=array();
                    $comment_obj = new Comment();
                    $comment_obj->setContent($comment);
                    $comment_obj->setEnabled(true);
                    $comment_obj->setUser($user_obj);

                    $em=$this->getDoctrine()->getManager();
                    $comment_obj->setPoster($poster_obj);
                    
                    $em->persist($comment_obj);
                    $em->flush();  
                    $errors[]=array("name"=>"id","value"=>$comment_obj->getId());
                    $errors[]=array("name"=>"content","value"=>$comment_obj->getContent());
                    $errors[]=array("name"=>"user","value"=>$comment_obj->getUser()->getName());
                    $errors[]=array("name"=>"enabled","value"=>$comment_obj->getEnabled());
                    $errors[]=array("name"=>"image","value"=>$imagineCacheManager->getBrowserPath($comment_obj->getUser()->getMedia()->getPath(), 'thumb_square_100')) ;   
                    $errors[]=array("name"=>"created","value"=>"now");
                    $message="Your comment has been added";
                
            }else {
                $code = "500";
                $message = "Sorry, Your comment could not be added at this time";

            }
        } else {
            $code = "500";
            $message = "Sorry, your comment could not be added at this time";
        }

        $error=array(
            "code"=>$code,
            "message"=>$message,
            "values"=>$errors
        );
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($error, 'json');
        return new Response($jsonContent);
    }


    public function hide($id,Request $request) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $comment = $em->getRepository("App\Admin\Entity\Comment")->find($id);
        if($comment==null){
            throw new NotFoundHttpException("Page not found");
        }
        $user=$comment->getUser();
	      if ($comment->getEnabled()==true) {
	        $comment->setEnabled(false);
	      }else{
	        $comment->setEnabled(true);
	      }
        $em->flush();
        $this->addFlash('success', 'Operation has been done successfully');
        return  $this->redirect($request->server->get('HTTP_REFERER'));
    }


    public function delete($id,Request $request) : Response
    {
        $em=$this->getDoctrine()->getManager();

        $comment = $em->getRepository("App\Admin\Entity\Comment")->find($id);
        if($comment==null){
            throw new NotFoundHttpException("Page not found");
        }
        $poster=$comment->getPoster();
        $user=$comment->getUser();
        if ($request->query->has("user")) {
            $url = $this->generateUrl('app_admin_user_comments',array("id"=>$user->getId()));
        }
        else if ($request->query->has("poster")) {
            if ($poster==null) {
                $url = $this->generateUrl('app_admin_comment_index');
            }else{
                if ($poster->getType() == "movie") {
                    $url = $this->generateUrl('app_admin_movie_comments',array("id"=>$poster->getId()));
                }else{
                    $url = $this->generateUrl('app_admin_serie_comments',array("id"=>$poster->getId()));
                }     
            }
        }
        else{
            $url = $this->generateUrl('app_admin_comment_index');
        }
        
        $em->remove($comment);
        $em->flush();
        $this->addFlash('success', 'Operation has been done successfully');
        return $this->redirect($url);
        
    }
}
