<?php 
namespace App\Admin\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Admin\Entity\Subtitle;
use App\Media\Entity\Media;
use App\Admin\Form\SubtitleType;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormError;

class SubtitleController extends AbstractController
{
 

 
    
    public function api_by_episode(Request $request,$token,$purchase,$id) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();
        $list=array();

       $episode = $em->getRepository('App\Admin\Entity\Episode')->find($id);
       if($episode==null){
            throw new NotFoundHttpException("Page not found");  
       }

        $subtitles = $em->getRepository('App\Admin\Entity\Subtitle')->findBy(array("episode"=>$episode));

           $subtitles_list = array();
           foreach ($subtitles as $key => $subtitle) {
                $s["id"]=$subtitle->getId();
                $s["language"]=$subtitle->getLanguage();
                $s["type"]=$subtitle->getMedia()->getExtension();
                $s["url"]=$request->getScheme() . "://" .$request->getHttpHost().$this->generateUrl('api_admin_subtitle_by_id',array("id"=>$subtitle->getId(),"token"=>$token,"purchase"=>$purchase));
                $subtitles_list[]=$s;
           }
          
        
       
        header('Content-Type: application/json'); 
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($subtitles_list, 'json');
        return new Response($jsonContent);
    }
    public function api_by_id(Request $request,$token,$id) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();

       $subtitle = $em->getRepository('App\Admin\Entity\Subtitle')->find($id);
       if($subtitle==null){
            throw new NotFoundHttpException("Page not found");  
       }
       $media = $subtitle->getMedia();
        $file_name = $media->getPath();
        $result = file_get_contents($media->getPath());

        header("Content-Type:text/vtt;charset=utf-8");
        header('Access-Control-Allow-Origin: *');  
        header("Access-Control-Max-Age: 3628800");
        header("Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS");
        header("Access-Control-Allow-Headers: X-Requested-With");
        header("Access-Control-Allow-Headers: Authorization");

        echo str_replace("\n\n\n","\n\n",str_replace("،",".",$result));
        return new Response("");
      // return $this->render("Admin/Subtitle/show.html.php",array("subtitle"=>$subtitle));
    }
    public function api_by_movie(Request $request,$token,$purchase,$id) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();
        $list=array();

       $poster = $em->getRepository('App\Admin\Entity\Poster')->find($id);
       if($poster==null){
            throw new NotFoundHttpException("Page not found");  
       }


        $subtitles = $em->getRepository('App\Admin\Entity\Subtitle')->findBy(array("poster"=>$poster));

           $subtitles_list = array();
           foreach ($subtitles as $key => $subtitle) {
                $s["id"]=$subtitle->getId();
                $s["language"]=$subtitle->getLanguage();
                $s["type"]=$subtitle->getMedia()->getExtension();
                $s["url"]=$request->getScheme() . "://" .$request->getHttpHost().$this->generateUrl('api_admin_subtitle_by_id',array("id"=>$subtitle->getId(),"token"=>$token,"purchase"=>$purchase));
                $subtitles_list[]=$s;
           }
          
        
        header('Content-Type: application/json'); 
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($subtitles_list, 'json');
        return new Response($jsonContent);
    }
    public function add(Request $request,$poster) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $movie=$em->getRepository("App\Admin\Entity\Poster")->find($poster);

        if ($movie==null) {
            throw new NotFoundHttpException("Page not found");
        }

        $subtitle = new Subtitle();
        $form = $this->createForm(SubtitleType::class,$subtitle);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            if ($subtitle->getFile()!=null ){
                $subtitlemedia= new Media();
                $subtitlemedia->setFile($subtitle->getFile());
                $subtitlemedia->upload($this->getParameter('files_directory'));
                $em->persist($subtitlemedia);
                $em->flush();
                $subtitle->setMedia($subtitlemedia);
                $subtitle->setPoster($movie);
                $em->persist($subtitle);
                $em->flush();  
                if ($subtitle->getFile()->getClientOriginalExtension() == "srt") {
                    $media = $subtitle->getMedia();

                    $file_name = $media->getPath();
                    $result = file_get_contents($media->getPath());
                    
                    $op1 = str_replace(",", ".", $result);
                    
                    $file_name_vtt = str_replace( "srt", "vtt",$file_name);
                    $txt = "WEBVTT\n\n";
                    $txt .= $op1;
                    $myfile = fopen($file_name_vtt, "w");
                    fwrite($myfile, $txt);
                    fclose($myfile);

                    $media->setUrl(str_replace("srt","vtt",$media->getUrl()));
                    $media->setExtension(str_replace("srt","vtt",$media->getExtension()));
                    $media->setType(str_replace("srt","vtt",$media->getType()));
                    $em->flush();  
                    sleep(1);
                    @unlink($file_name);

                }
                $this->addFlash('success', 'Operation has been done successfully');
                return $this->redirect($this->generateUrl('app_admin_movie_subtitles',array("id"=>$movie->getId())));
            }else{
                $error = new FormError("Required image file");
                $form->get('file')->addError($error);
            }
        }
        return $this->render("Admin/Subtitle/add.html.twig",array("movie"=>$movie,"form"=>$form->createView()));
    }
    public function add_episode(Request $request,$episode) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $episode=$em->getRepository("App\Admin\Entity\Episode")->find($episode);

        if ($episode==null) {
            throw new NotFoundHttpException("Page not found");
        }

        $subtitle = new Subtitle();
        $form = $this->createForm(SubtitleType::class,$subtitle);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            if ($subtitle->getFile()!=null ){
                $subtitlemedia= new Media();
                $subtitlemedia->setFile($subtitle->getFile());
                $subtitlemedia->upload($this->getParameter('files_directory'));
                $em->persist($subtitlemedia);
                $em->flush();
                $subtitle->setMedia($subtitlemedia);
                $subtitle->setEpisode($episode);
                $em->persist($subtitle);
                $em->flush();  

                if ($subtitle->getFile()->getClientOriginalExtension() == "srt") {
                    $media = $subtitle->getMedia();

                    $file_name = $media->getPath();
                    $result = file_get_contents($media->getPath());
                    
                    $op1 = str_replace(",", ".", $result);
                    
                    $file_name_vtt = str_replace( "srt", "vtt",$file_name);
                    $txt = "WEBVTT\n\n";
                    $txt .= $op1;
                    $myfile = fopen($file_name_vtt, "w");
                    fwrite($myfile, $txt);
                    fclose($myfile);

                    $media->setUrl(str_replace("srt","vtt",$media->getUrl()));
                    $media->setExtension(str_replace("srt","vtt",$media->getExtension()));
                    $media->setType(str_replace("srt","vtt",$media->getType()));
                    $em->flush();  
                    sleep(1);
                    @unlink($file_name);

                }
            
                $this->addFlash('success', 'Operation has been done successfully');
                return $this->redirect($this->generateUrl('app_admin_episode_subtitles',array("id"=>$episode->getId())));
            }else{
                $error = new FormError("Required image file");
                $form->get('file')->addError($error);
            }
        }
        return $this->render("Admin/Subtitle/add_episode.html.twig",array("episode"=>$episode,"form"=>$form->createView()));
    }
    public function delete($id,Request $request) : Response
    {
        $em=$this->getDoctrine()->getManager();

        $subtitle = $em->getRepository("App\Admin\Entity\Subtitle")->find($id);
        if($subtitle==null){
            throw new NotFoundHttpException("Page not found");
        }
        
        $movie=$subtitle->getPoster();
        $episode=$subtitle->getEpisode();

        if($movie!=null)
           $url = $this->generateUrl("app_admin_movie_subtitles",array("id"=>$movie->getId()));
        if($episode!=null)
           $url =  $this->generateUrl("app_admin_episode_subtitles",array("id"=>$episode->getId()));



            $media_old = $subtitle->getMedia();
            $em->remove($subtitle);
            $em->flush();
            if( $media_old!=null ){
                $media_old->delete($this->getParameter('files_directory'));
                $em->remove($media_old);
                $em->flush();
            }
            $this->addFlash('success', 'Operation has been done successfully');
            return $this->redirect($url);
        
    }

}
?>