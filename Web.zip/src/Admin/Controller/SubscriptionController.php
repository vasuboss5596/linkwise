<?php 
namespace App\Admin\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Media\Entity\Media;
use App\Admin\Entity\Subscription;
use App\Admin\Form\SubscriptionType;

use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Knp\Component\Pager\PaginatorInterface;

class SubscriptionController extends AbstractController
{

    public function api_disable(Request $request,$token) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em = $this->getDoctrine()->getManager();
        $user_id=$request->get("user");
        $key=$request->get("key");        
        $id=$request->get("id");        
        $user_obj=$em->getRepository("App\Auth\Entity\User")->find($user_id);
        $list=array();
        $code = 500;
        if(sha1($user_obj->getPassword()) == $key and $user_obj->isEnabled()) {
            $subscriptions=$em->getRepository("App\Admin\Entity\Subscription")->findBy(array("transaction"));
            foreach ($subscriptions as $key => $subscription) {
                $subscription->setExpired(new \DateTime);
            }
            $em->flush();
            $code = 200;
        }

        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($code, 'json');
        return new Response($jsonContent);
      
    }
    public function api_by_user(Request $request,$token) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em = $this->getDoctrine()->getManager();
        $id=$request->get("user");
        $key=$request->get("key");        
        $user_obj=$em->getRepository("App\Auth\Entity\User")->find($id);
        $list=array();

        if(sha1($user_obj->getPassword()) == $key and $user_obj->isEnabled()) {

            foreach ($user_obj->isSubscribed() as $key => $subscription) {
                $a = null;
                $a["id"]=$subscription->getId();
                $a["price"]= (($subscription->getCoupon() != null)? $subscription->getTotalprice()." ".$subscription->getCurrency()." - (". $subscription->getCoupon()->getDiscount().(($subscription->getCoupon()->getType() == "value")?  "".$subscription->getCurrency():"%" ) .") = ":"") . $subscription->getPrice()." ".$subscription->getCurrency();
                $a["plan"]=$subscription->getPlan();
                $a["method"]=$subscription->getMethod();
                $a["expired"]=($subscription->getExpired() == null)?"Expired : Undefined":"Expired : ".$subscription->getExpired()->format("Y/m/d H:i");
                $a["state"]=$subscription->getStatus();
                $a["date"]=($subscription->getCreated() == null)?"Started : Undefined":"Started : ".$subscription->getCreated()->format("Y/m/d H:i");
                $a["qualities"]=$subscription->getQualities();
                $a["downloads"]=$subscription->getDownloads();
                $a["sessions"]=$subscription->getSessions();
                $a["transaction"]=$subscription->getTransaction();
                $list[]=$a;
            }

        }

        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($list, 'json');
        return new Response($jsonContent);
      
    }
    public function api_by_user_all(Request $request,$token) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em = $this->getDoctrine()->getManager();
        $id=$request->get("user");
        $key=$request->get("key");        
        $user_obj=$em->getRepository("App\Auth\Entity\User")->find($id);
        $list=array();

        if(sha1($user_obj->getPassword()) == $key and $user_obj->isEnabled()) {
            $subscriptions =  $em->getRepository("App\Admin\Entity\Subscription")->findBy(array("user"=>$user_obj));
            foreach ($subscriptions as $key => $subscription) {
                $a = null;
                $a["id"]=$subscription->getId();
                $a["price"]= (($subscription->getCoupon() != null)? $subscription->getTotalprice()." ".$subscription->getCurrency()." - (". $subscription->getCoupon()->getDiscount().(($subscription->getCoupon()->getType() == "value")?  "".$subscription->getCurrency():"%" ) .") = ":"") . $subscription->getPrice()." ".$subscription->getCurrency();
                $a["plan"]=$subscription->getPlan();
                $a["method"]=$subscription->getMethod();
                $a["expired"]=($subscription->getExpired() == null)?"Expired : Undefined":"Expired : ".$subscription->getExpired()->format("Y/m/d H:i");
                $a["state"]=$subscription->getStatus();
                $a["date"]=($subscription->getCreated() == null)?"Started : Undefined":"Started : ".$subscription->getCreated()->format("Y/m/d H:i");
                $a["qualities"]=$subscription->getQualities();
                $a["downloads"]=$subscription->getDownloads();
                $a["sessions"]=$subscription->getSessions();
                $a["transaction"]=$subscription->getTransaction();
                $list[]=$a;



            }

        }

        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($list, 'json');
        return new Response($jsonContent);
      
    }
    public function index(Request $request,PaginatorInterface $paginator) : Response
    {

        $em = $this->getDoctrine()->getManager();
        $q = " ";
        if ($request->query->has("status") and $request->query->get("status") != "all") {
            $q .= " AND  p.status like '" . $request->query->get("status") . "'";
        }

        $dql = "SELECT p FROM App\Admin\Entity\Subscription p  WHERE 1 = 1 " . $q . " ORDER BY p.created desc ";
        $query = $em->createQuery($dql);
        $subscriptions = $paginator->paginate(
            $query,
            $request->query->getInt('page', 1),
            20
        );

        $subscription_count= $em->getRepository("App\Admin\Entity\Subscription")->countAll();
        $subscription_count_paid= $em->getRepository("App\Admin\Entity\Subscription")->countPaid();
        $subscription_count_unpaid= $em->getRepository("App\Admin\Entity\Subscription")->countUnpaid();
        $subscription_count_pendding= $em->getRepository("App\Admin\Entity\Subscription")->countPendding();

        return $this->render('Admin/Subscription/index.html.twig', array("subscription_count_paid"=>$subscription_count_paid,"subscription_count_unpaid"=>$subscription_count_unpaid,"subscription_count_pendding"=>$subscription_count_pendding,"subscription_count"=>$subscription_count,"subscriptions" => $subscriptions));
    }
    public function delete($id,Request $request) : Response
    {
        $em=$this->getDoctrine()->getManager();

        $subscription = $em->getRepository("App\Admin\Entity\Subscription")->find($id);
        if($subscription==null){
            throw new NotFoundHttpException("Page not found");
        }

            $media_old = $subscription->getMedia();
            $em->remove($subscription);
            $em->flush();
            if( $media_old!=null ){
                $media_old->delete($this->getParameter('files_directory'));
                $em->remove($media_old);
                $em->flush();
            }
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
            return $this->redirect($this->generateUrl('app_admin_subscription_index'));
        
    }
    public function edit(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $subscription=$em->getRepository("App\Admin\Entity\Subscription")->find($id);
        if ($subscription==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $form = $this->createForm(SubscriptionType::class,$subscription);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
            return $this->redirect($this->generateUrl('app_admin_subscription_index'));
 
        }
        return $this->render("Admin/Subscription/edit.html.twig",array("subscription"=>$subscription,"form"=>$form->createView()));
    }
    public function api_intent(Request $request,$token) : Response
    {

        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();

        $settings = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());

           
        $user=$request->get("user");
        $key=$request->get("key");
        $plan_id=$request->get("plan");
        $coupon_code=$request->get("coupon");


        $settings = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());

        $user_obj=$em->getRepository("App\Auth\Entity\User")->find($user);
        $plan=$em->getRepository("App\Admin\Entity\Plan")->find($plan_id);
        $code = 500;
        $message = "";
        $values= array();
        if ($user_obj != null and $plan != null) {
            if (sha1($user_obj->getPassword()) == $key and $user_obj->isEnabled()) {

                $price  = $plan->getPrice();


                $coupon = $em->getRepository("App\Admin\Entity\Coupon")->findOneBy(array("code"=>$coupon_code));
                if ($coupon != null) {

                    if ($coupon->getExpired() < new \DateTime() )  {
                    }else{
                        

                        if ($coupon->getType() == "value") {
                             $price =  $price - $coupon->getDiscount();
                        }else{
                             $discount_value = $coupon->getDiscount()/100;
                             $discount_value = $price*$discount_value;
                             $price = $price - $discount_value;

                        }
                    }  
                } 
            

                \Stripe\Stripe::setApiKey($settings->getStripeapikey());
                $intent =  \Stripe\PaymentIntent::create([
                  'amount' => $price*100,
                  'currency' => strtolower($settings->getCurrency()),
                  'payment_method_types' => ['card'],
                    'metadata' => [
                        'user_id' => $user_obj->getId(),
                        "plan_id" => $plan->getId()
                    ],
                ]);
                $values[]=array("name"=>"client_secret","value"=>$intent->client_secret); 
                $code =200;

            }
        }
        $error=array(
            "code"=>$code,
            "message"=>$message,
            "values"=>$values
        );
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($error, 'json');
        return new Response($jsonContent);
    }
    public function api_google(Request $request,$token) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();

        $settings = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());

        $user=$request->get("user");
        $id=$request->get("id");
        $key=$request->get("key");
        $plan_id=$request->get("plan");

        $user_obj=$em->getRepository("App\Auth\Entity\User")->find($user);
        $plan=$em->getRepository("App\Admin\Entity\Plan")->find($plan_id);



        $code = 200;
        $message = "";
        $values= array();
        if ($user_obj != null and $plan != null) {
            if (sha1($user_obj->getPassword()) == $key and $user_obj->isEnabled()) {
                
                $code=200;
                $message="Congratulations you are now subscribed!";
                $values=array();


                $subscription =  new Subscription();
                $subscription->setMethod("google");
                $subscription->setPlan($plan->getTitle());
                $subscription->setPrice($plan->getPrice());
                $subscription->setTotalprice($plan->getPrice());
                $subscription->setCurrency($settings->getCurrency());
                $subscription->setUser($user_obj);
                $subscription->setStatus("paid");
                $subscription->setTransaction($id);
                $subscription->setDuration($plan->getDuration());
                $subscription->setQualities($plan->getQualities());
                $subscription->setDownloads($plan->getDownloads());
                $subscription->setSessions($plan->getSessions());
                $em->persist($subscription);
                $em->flush();
                $values[]=array("name"=>"expired","value"=> ($subscription->getExpired() == null)?"Expired : Undefined":"Expired : ".$subscription->getExpired()->format("Y/m/d H:i"));


            }else {
                $code = 500;
                $message = "The payment not received, Please contact our support team";
            }
        } else {
            $code = 500;
            $message = "The payment not received, Please contact our support team";
        }

        $error=array(
            "code"=>$code,
            "message"=>$message,
            "values"=>$values
        );
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($error, 'json');
        return new Response($jsonContent);
    }
    public function api_paypal(Request $request,$token) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();

        $settings = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());

        $user=$request->get("user");
        $id=$request->get("id");
        $key=$request->get("key");
        $plan_id=$request->get("plan");
        $coupon_code=$request->get("coupon");

        $user_obj=$em->getRepository("App\Auth\Entity\User")->find($user);
        $plan=$em->getRepository("App\Admin\Entity\Plan")->find($plan_id);



        $code = 200;
        $message = "";
        $values= array();
        if ($user_obj != null and $plan != null) {
            if (sha1($user_obj->getPassword()) == $key and $user_obj->isEnabled()) {
                
                $code=201;
                $message="Thank you for your payment, we will notify you when your payment is complete.";
                $values=array();


                $subscription =  new Subscription();
                $subscription->setMethod("paypal");
                $subscription->setPlan($plan->getTitle());
                $subscription->setPrice($plan->getPrice());
                $subscription->setTotalprice($plan->getPrice());
                $subscription->setCurrency($settings->getCurrency());
                $subscription->setUser($user_obj);
                $subscription->setStatus("pendding");
                $subscription->setTransaction($id);
                $subscription->setDuration($plan->getDuration());
                $subscription->setQualities($plan->getQualities());
                $subscription->setDownloads($plan->getDownloads());
                $subscription->setSessions($plan->getSessions());
                $em->persist($subscription);
                $em->flush();


                $coupon = $em->getRepository("App\Admin\Entity\Coupon")->findOneBy(array("code"=>$coupon_code));
                if ($coupon != null) {

                    if ($coupon->getExpired() < new \DateTime() )  {
                    }else{
                        $subscription->setCoupon($coupon);
                        $em->flush();

                        if ($coupon->getType() == "value") {
                             $subscription->setPrice($subscription->getTotalprice() - $coupon->getDiscount());
                             $em->flush();
                        }else{
                             $discount_value = $coupon->getDiscount()/100;
                             $discount_value = $subscription->getTotalprice()*$discount_value;
                             $subscription->setPrice($subscription->getTotalprice() - $discount_value);
                             $em->flush();

                        }
                    }  
                } 





                $uri =  (($settings->getPaypalsandbox())? 'https://api.sandbox.':'https://api.').'paypal.com/v1/oauth2/token';

                $clientId = $settings->getPaypalclientid();
                $secret = $settings->getPaypalClientsecret();

                $ch = curl_init();

                curl_setopt($ch, CURLOPT_URL, $uri);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSLVERSION , 6); //NEW ADDITION
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
                curl_setopt($ch, CURLOPT_USERPWD, $clientId.":".$secret);
                curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");

                $result = curl_exec($ch);
                $access_token = '';
                if(empty($result))die("Error: No response.");

                else
                {
                    $json = json_decode($result);
                    $access_token = $json->access_token;
                }

                curl_close($ch);

                $url = (($settings->getPaypalsandbox())? 'https://api.sandbox.':'https://api.')."paypal.com/v2/checkout/orders/".$id;
                $accessToken=$access_token;
                $curl = curl_init($url);
                curl_setopt($curl, CURLOPT_POST, false);
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($curl, CURLOPT_HEADER, false);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                    'Authorization: Bearer ' . $accessToken,
                    'Accept: application/json',
                    'Content-Type: application/json'
                ));
                $response = curl_exec($curl);
                $response_array = json_decode($response,TRUE);
                $payer_email = "";
                $currency = "";
                $price = "";
                $user_id_pp ="";
                $plan_id_pp ="";
                $status = "";
                if (array_key_exists("purchase_units", $response_array)) {
                  if (sizeof($response_array["purchase_units"])>0) {
                        if (array_key_exists("amount", $response_array["purchase_units"][0])) {
                            $currency = $response_array["purchase_units"][0]["amount"]["currency_code"];
                            $price = $response_array["purchase_units"][0]["amount"]["value"];
                            
                        }
                        if (array_key_exists("custom_id", $response_array["purchase_units"][0])) {
                            $data =  explode(",",$response_array["purchase_units"][0]["custom_id"]);
                            $user_id_pp = str_replace("user:", "",$data[0]);
                            $plan_id_pp = str_replace("plan:", "",$data[1]);
                        }
                  }
                    
                }
                if (array_key_exists("status", $response_array)) {
                    $status = $response_array["status"];
                }
                if (array_key_exists("payer", $response_array)) {
                    if (array_key_exists("email_address", $response_array["payer"])) {
                            $payer_email = $response_array["payer"]["email_address"];

                    }
                }
               



                if (
                    $user_id_pp == $user &&
                    $plan_id_pp == $plan_id &&
                    $price == $subscription->getPrice() &&
                    $status == "COMPLETED" && 
                    strtoupper($currency) == strtoupper($settings->getCurrency())
                ){
                    $started =  new \DateTime();
                    $expired =  new \DateTime();
                    $expired->modify('+'.$subscription->getDuration()." day");

                    $subscription->setStarted($started);
                    $subscription->setExpired($expired);
                    $subscription->setEmail($payer_email);
                    $subscription->setStatus("paid");
                    $em->flush();
                    $code = 200;
                    $values[]=array("name"=>"expired","value"=> ($subscription->getExpired() == null)?"Expired : Undefined":"Expired : ".$subscription->getExpired()->format("Y/m/d H:i"));
                    $message="Congratulations you are now subscribed!";

                }else{
                    $subscription->setStatus("pendding");
                    $em->flush();
                    $code=201;
                    $message="Thank you for your payment, we will notify you when your payment is complete.";
                }
            
            }else {
                $code = 500;
                $message = "The payment not received, Please contact our support team";
            }
        } else {
            $code = 500;
            $message = "The payment not received, Please contact our support team";
        }

        $error=array(
            "code"=>$code,
            "message"=>$message,
            "values"=>$values
        );
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($error, 'json');
        return new Response($jsonContent);
    }
    public function api_stripe(Request $request,$token) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();

        $settings = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());
        $user=$request->get("user");
        $id=$request->get("id");
        $key=$request->get("key");
        $plan_id=$request->get("plan");
        $coupon_code=$request->get("coupon");

        $user_obj=$em->getRepository("App\Auth\Entity\User")->find($user);
        $plan=$em->getRepository("App\Admin\Entity\Plan")->find($plan_id);



        $code = 200;
        $message = "";
        $values= array();
        if ($user_obj != null and $plan != null) {
            if (sha1($user_obj->getPassword()) == $key and $user_obj->isEnabled()) {
                
                $code=201;
                $message="Thank you for your payment, we will notify you when your payment is complete.";
                $values=array();
                    \Stripe\Stripe::setApiKey($settings->getStripeapikey());

                    $intent = \Stripe\PaymentIntent::retrieve($id);
                    $charges = $intent->charges->data;

                    $subscription=$em->getRepository("App\Admin\Entity\Subscription")->findOneBy(array("transaction"=>$id));

                    if ($subscription == null) {                
                        $subscription =  new Subscription();
                        $subscription->setMethod("card");
                        $subscription->setPlan($plan->getTitle());
                        $subscription->setPrice($plan->getPrice());
                        $subscription->setTotalprice($plan->getPrice());
                        $subscription->setCurrency($settings->getCurrency());
                        $subscription->setUser($user_obj);
                        $subscription->setStatus("pendding");
                        $subscription->setTransaction($id);
                        $subscription->setDuration($plan->getDuration());
                        $subscription->setQualities($plan->getQualities());
                        $subscription->setDownloads($plan->getDownloads());
                        $subscription->setSessions($plan->getSessions());
                        $em->persist($subscription);
                        $em->flush(); 

                        $coupon = $em->getRepository("App\Admin\Entity\Coupon")->findOneBy(array("code"=>$coupon_code));
                        if ($coupon != null) {

                            if ($coupon->getExpired() < new \DateTime() )  {
                            }else{
                                $subscription->setCoupon($coupon);
                                $em->flush();

                                if ($coupon->getType() == "value") {
                                     $subscription->setPrice($subscription->getTotalprice() - $coupon->getDiscount());
                                     $em->flush();
                                }else{
                                     $discount_value = $coupon->getDiscount()/100;
                                     $discount_value = $subscription->getTotalprice()*$discount_value;
                                     $subscription->setPrice($subscription->getTotalprice() - $discount_value);
                                     $em->flush();

                                }
                            }  
                        } 


                        if (
                            $charges[0]->metadata->user_id == $user_obj->getId() &&
                            $charges[0]->metadata->plan_id == $plan->getId() &&
                            $charges[0]->amount == $subscription->getPrice()*100 &&
                            $charges[0]->status == "succeeded" && 
                            strtoupper($charges[0]->currency) == strtoupper($settings->getCurrency())
                        ){
                            $started =  new \DateTime();
                            $expired =  new \DateTime();
                            $expired->modify('+'.$subscription->getDuration()." day");

                            $subscription->setStarted($started);
                            $subscription->setExpired($expired);

                            $subscription->setTransaction($intent->id);
                            $subscription->setStatus("paid");
                            $em->flush();
                            $code = 200;
                            $message="Congratulations you are now subscribed!";
                            $values[]=array("name"=>"expired","value"=> ($subscription->getExpired() == null)?"Expired : Undefined":"Expired : ".$subscription->getExpired()->format("Y/m/d H:i"));

                        }else{
                            $subscription->setStatus("pendding");
                            $em->flush();
                            $code=201;
                            $message="Thank you for your payment, we will notify you when your payment is complete.";
                        } 



                    }else{
                         $code = 500;
                         $message = "The payment not received, Please contact our support team";
                    }         
            }else {
                $code = 500;
                $message = "The payment not received, Please contact our support team";
            }
        }else {
            $code = 500;
            $message = "The payment not received, Please contact our support team";
        }

        $error=array(
            "code"=>$code,
            "message"=>$message,
            "values"=>$values
        );
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($error, 'json');
        return new Response($jsonContent);
    }
    public function api_cash(Request $request,$token) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();

        $settings = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array(), array());
        
        $user=str_replace('"', "",$request->get("user"));
        $id=str_replace('"', "",$request->get("id"));
        $infos=str_replace('"', "",$request->get("infos"));
        $key=str_replace('"', "",$request->get("key"));
        $plan_id=str_replace('"', "",$request->get("plan"));
        $coupon_code=str_replace('"', "",$request->get("coupon"));

        $user_obj=$em->getRepository("App\Auth\Entity\User")->find($user);
        $plan=$em->getRepository("App\Admin\Entity\Plan")->find($plan_id);

        $code = 200;
        $message = "";
        $values= array();
        if ($user_obj != null and $plan != null) {
            if (sha1($user_obj->getPassword()) == $key and $user_obj->isEnabled()) {
                
                    $code=200;
                    $message="Thank you for your payment, we will notify you when your payment is complete.";
                    $values=array();
                    
                    $subscription=$em->getRepository("App\Admin\Entity\Subscription")->findOneBy(array("transaction"=>$id));

                    if ($subscription == null) { 
                        $subscription =  new Subscription();
                        $subscription->setMethod("cash");
                        $subscription->setPlan($plan->getTitle());
                        $subscription->setPrice($plan->getPrice());
                        $subscription->setTotalprice($plan->getPrice());
                        $subscription->setCurrency($settings->getCurrency());
                        $subscription->setUser($user_obj);
                        $subscription->setStatus("pendding");
                        $subscription->setTransaction($id);
                        $subscription->setInfos($infos);
                        $subscription->setDuration($plan->getDuration());
                        $subscription->setQualities($plan->getQualities());
                        $subscription->setDownloads($plan->getDownloads());
                        $subscription->setSessions($plan->getSessions());
                        if($request->files->get('uploaded_file')){
                            $media= new Media();
                            $media->setFile($request->files->get('uploaded_file'));
                            $media->upload($this->getParameter('files_directory'));
                            $media->setEnabled(true);
                            $em->persist($media);
                            $em->flush();
                            $subscription->setMedia($media);
                        }
                        $em->persist($subscription);
                        $em->flush(); 


                        $coupon = $em->getRepository("App\Admin\Entity\Coupon")->findOneBy(array("code"=>$coupon_code));
                        if ($coupon != null) {

                            if ($coupon->getExpired() < new \DateTime() )  {
                            }else{
                                $subscription->setCoupon($coupon);
                                $em->flush();

                                if ($coupon->getType() == "value") {
                                     $subscription->setPrice($subscription->getTotalprice() - $coupon->getDiscount());
                                     $em->flush();
                                }else{
                                     $discount_value = $coupon->getDiscount()/100;
                                     $discount_value = $subscription->getTotalprice()*$discount_value;
                                     $subscription->setPrice($subscription->getTotalprice() - $discount_value);
                                     $em->flush();

                                }
                            }  
                        } 
            


                    }else{
                         $code = 500;
                        $message = "The payment not received, Please contact our support team";
                    }         
            }else {
                $code = 500;
                $message = "The payment not received, Please contact our support team";
            }
        }else {
            $code = 500;
            $message = "The payment not received, Please contact our support team";
        }

        $error=array(
            "code"=>$code,
            "message"=>$message,
            "values"=>$values
        );
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($error, 'json');
        return new Response($jsonContent);
    }
}
?>