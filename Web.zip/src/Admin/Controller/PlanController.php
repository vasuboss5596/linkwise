<?php 
namespace App\Admin\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Admin\Entity\Plan;
use App\Media\Entity\Media;
use App\Admin\Form\PlanType;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;

class PlanController extends AbstractController
{
    public function index() : Response
    {
        $em = $this->getDoctrine()->getManager();
        $plans =   $em->getRepository("App\Admin\Entity\Plan")->findBy(array());
        return $this->render("Admin/Plan/index.html.twig",array("plans"=>$plans));
    }

    public function api_all(Request $request,$token) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();

        $list=array();
        $plans =   $em->getRepository("App\Admin\Entity\Plan")->findBy(array());
        foreach ($plans as $key => $plan) {
            $s["id"]=$plan->getId();
            $s["title"]=$plan->getTitle();
            $s["description"]=$plan->getDescription();
            $s["discount"]=$plan->getDiscount();
            $s["price"]=$plan->getPrice();
            $s["duration"]=$plan->getDuration();
            $s["qualities"]=$plan->getQualities();
            $s["downloads"]=$plan->getDownloads();
            $s["sessions"]=$plan->getSessions();
            $s["subscriptionid"]=$plan->getSubscriptionid();
            $list[]=$s;
        }
        header('Content-Type: application/json'); 
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent=$serializer->serialize($list, 'json');
        return new Response($jsonContent);
    }

    public function add(Request $request) : Response
    {
        $plan= new Plan();
        $form = $this->createForm(PlanType::class,$plan);
        $em=$this->getDoctrine()->getManager();
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($plan);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
            return $this->redirect($this->generateUrl('app_admin_plan_index'));
       }
        $settings=$em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());

        return $this->render("Admin/Plan/add.html.twig",array("settings"=>$settings,"form"=>$form->createView()));
    }
    public function delete($id,Request $request) : Response
    {
        $em=$this->getDoctrine()->getManager();

        $plan = $em->getRepository("App\Admin\Entity\Plan")->find($id);
        if($plan==null){
            throw new NotFoundHttpException("Page not found");
        }
        if(1==1){
            $plans=$em->getRepository('App\Admin\Entity\Plan')->findBy(array());
            $em->remove($plan);
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
        }else{
            $this->addFlash('danger', "Plan already associated with a user's subscriptions"); 
        }

        return $this->redirect($this->generateUrl('app_admin_plan_index'));
        
    }
    public function edit(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $plan=$em->getRepository("App\Admin\Entity\Plan")->find($id);
        $settings=$em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());
        if ($plan==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $form = $this->createForm(PlanType::class,$plan);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
            return $this->redirect($this->generateUrl('app_admin_plan_index'));
 
        }
        return $this->render("Admin/Plan/edit.html.twig",array("settings"=>$settings,"plan"=>$plan,"form"=>$form->createView()));
    }
}
?>