<?php 
namespace App\Admin\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Admin\Entity\Source;
use App\Admin\Entity\Episode;
use App\Media\Entity\Media;
use App\Admin\Form\EpisodeType;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;

class EpisodeController extends AbstractController
{
 

    public function edit(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $episode=$em->getRepository("App\Admin\Entity\Episode")->findOneBy(array("id"=>$id));
        if ($episode==null) {
            throw new NotFoundHttpException("Page not found");
        }

        $form = $this->createForm(EpisodeType::class,$episode);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
                if ($episode->getFile()!=null ){

                    $media_cover_old = $episode->getMedia();


                    $episodemedia= new Media();
                    $episodemedia->setFile($episode->getFile());
                    $episodemedia->upload($this->getParameter('files_directory'));
                    $em->persist($episodemedia);
                    $em->flush();
                    $episode->setMedia($episodemedia);

                    if ($media_cover_old!=null) {
                        $media_cover_old->delete($this->getParameter('files_directory'));
                        $em->remove($media_cover_old);
                        $em->flush();
                    }
                    
                }
                $em->flush();  
                $this->addFlash('success', 'Operation has been done successfully');
                return $this->redirect($this->generateUrl('app_admin_serie_seasons',array("id"=>$episode->getSeason()->getPoster()->getId())));
           
        }

        return $this->render("Admin/Episode/edit.html.twig",array("season"=>$episode->getSeason(),"form"=>$form->createView()));
    }
    public function subtitles(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $episode=$em->getRepository("App\Admin\Entity\Episode")->find($id);
        if ($episode==null) {
            throw new NotFoundHttpException("Page not found");
        }
        return $this->render("Admin/Episode/subtitles.html.twig",array("episode"=>$episode));
    }
    public function torrents(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $episode=$em->getRepository("App\Admin\Entity\Episode")->find($id);
        if ($episode==null) {
            throw new NotFoundHttpException("Page not found");
        }

        return $this->render("Admin/Episode/torrents.html.twig",array("episode"=>$episode));
    }
    function get_image_mime_type($image_path) : Response
    {
        $mimes  = array(
            IMAGETYPE_GIF => "image/gif",
            IMAGETYPE_JPEG => "image/jpg",
            IMAGETYPE_PNG => "image/png",
            IMAGETYPE_SWF => "image/swf",
            IMAGETYPE_PSD => "image/psd",
            IMAGETYPE_BMP => "image/bmp",
            IMAGETYPE_TIFF_II => "image/tiff",
            IMAGETYPE_TIFF_MM => "image/tiff",
            IMAGETYPE_JPC => "image/jpc",
            IMAGETYPE_JP2 => "image/jp2",
            IMAGETYPE_JPX => "image/jpx",
            IMAGETYPE_JB2 => "image/jb2",
            IMAGETYPE_SWC => "image/swc",
            IMAGETYPE_IFF => "image/iff",
            IMAGETYPE_WBMP => "image/wbmp",
            IMAGETYPE_XBM => "image/xbm",
            IMAGETYPE_ICO => "image/ico");

        if (($image_type = exif_imagetype($image_path))
            && (array_key_exists($image_type ,$mimes)))
        {
            return $mimes[$image_type];
        }
        else
        {
            return FALSE;
        }
    }
   function get_image_ext_type($image_path) : Response
    {
        $mimes  = array(
            IMAGETYPE_GIF => "gif",
            IMAGETYPE_JPEG => "jpg",
            IMAGETYPE_PNG => "png",
            IMAGETYPE_SWF => "swf",
            IMAGETYPE_PSD => "psd",
            IMAGETYPE_BMP => "bmp",
            IMAGETYPE_TIFF_II => "tiff",
            IMAGETYPE_TIFF_MM => "tiff",
            IMAGETYPE_JPC => "jpc",
            IMAGETYPE_JP2 => "jp2",
            IMAGETYPE_JPX => "jpx",
            IMAGETYPE_JB2 => "jb2",
            IMAGETYPE_SWC => "swc",
            IMAGETYPE_IFF => "iff",
            IMAGETYPE_WBMP => "wbmp",
            IMAGETYPE_XBM => "xbm",
            IMAGETYPE_ICO => "ico");

        if (($image_type = exif_imagetype($image_path))
            && (array_key_exists($image_type ,$mimes)))
        {
            return $mimes[$image_type];
        }
        else
        {
            return FALSE;
        }
    }
    public function add(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $season=$em->getRepository("App\Admin\Entity\Season")->findOneBy(array("id"=>$id));
        if ($season==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $episode = new Episode();
        $form = $this->createForm(EpisodeType::class,$episode);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

                $episodemedia= new Media();
                $episodemedia->setFile($episode->getFile());
                $episodemedia->upload($this->getParameter('files_directory'));
                $em->persist($episodemedia);
                $em->flush();
                $episode->setMedia($episodemedia);

                $max=0;
                $episodes=$em->getRepository('App\Admin\Entity\Episode')->findBy(array("season"=>$season));
                foreach ($episodes as $key => $value) {
                    if ($value->getPosition()>$max) {
                        $max=$value->getPosition();
                    }
                }
                $episode->setPosition($max+1);
                $episode->setSeason($season);
                $em->persist($episode);
                $em->flush();  
                   
                $this->addFlash('success', 'Operation has been done successfully');
                return $this->redirect($this->generateUrl('app_admin_episode_torrents',array("id"=>$episode->getId())));
           
        }
        return $this->render("Admin/Episode/add.html.twig",array("season"=>$season,"form"=>$form->createView()));
    }
    public function up(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $episode=$em->getRepository("App\Admin\Entity\Episode")->find($id);
        if ($episode==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $season=$episode->getSeason();

        $rout =  'app_admin_serie_seasons';
        if ($episode->getPosition()>1) {
                $p=$episode->getPosition();
                $episodes=$em->getRepository('App\Admin\Entity\Episode')->findBy(array("season"=>$season),array("position"=>"asc"));
                foreach ($episodes as $key => $value) {
                    if ($value->getPosition()==$p-1) {
                        $value->setPosition($p);  
                    }
                }
                $episode->setPosition($episode->getPosition()-1);
                $em->flush(); 
        }
        return $this->redirect($this->generateUrl($rout,array("id"=>$season->getPoster()->getId())));

    }
    public function down(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $episode=$em->getRepository("App\Admin\Entity\Episode")->find($id);
        if ($episode==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $season=$episode->getSeason();

        $rout =  'app_admin_serie_seasons';

        $max=0;
        $episodes=$em->getRepository('App\Admin\Entity\Episode')->findBy(array("season"=>$season),array("position"=>"asc"));
        foreach ($episodes  as $key => $value) {
            $max=$value->getPosition();  
        }
        if ($episode->getPosition()<$max) {
            $p=$episode->getPosition();
            foreach ($episodes as $key => $value) {
                if ($value->getPosition()==$p+1) {
                    $value->setPosition($p);  
                }
            }
            $episode->setPosition($episode->getPosition()+1);
            $em->flush();  
        }
        return $this->redirect($this->generateUrl($rout,array("id"=>$season->getPoster()->getId())));    

    }

    public function api_add_share(Request $request, $token) {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $em = $this->getDoctrine()->getManager();
        $id = $request->get("id");
        $poster = $em->getRepository("App\Admin\Entity\Channel")->findOneBy(array("id"=>$id));
        if ($poster == null) {
            throw new NotFoundHttpException("Page not found");
        }
        $poster->setShares($poster->getShares() + 1);
        $em->flush();
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent = $serializer->serialize($poster->getShares(), 'json');
        return new Response($jsonContent);
    }
    public function api_add_view(Request $request, $token) {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $em = $this->getDoctrine()->getManager();
        $id = $request->get("id");
        $episode = $em->getRepository("App\Admin\Entity\Episode")->findOneBy(array("id"=>$id));
        if ($episode == null) {
            throw new NotFoundHttpException("Page not found");
        }
        $episode->setViews($episode->getViews() + 1);
        $em->flush();
        $serie = $episode->getSeason()->getPoster();
        $views = 0;
        foreach ($serie->getSeasons() as $key => $season) {
            foreach ($season->getEpisodes() as $key => $value) {
                $views += $value->getViews();
            }
        }
        $serie->setViews($views);
        $em->flush();

        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent = $serializer->serialize($episode->getViews(), 'json');
        return new Response($jsonContent);
    }
    public function api_add_download(Request $request, $token) {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $em = $this->getDoctrine()->getManager();
        $id = $request->get("id");
        $episode = $em->getRepository("App\Admin\Entity\Episode")->findOneBy(array("id"=>$id));
        if ($episode == null) {
            throw new NotFoundHttpException("Page not found");
        }
        $episode->setDownloads($episode->getDownloads() + 1);
        $em->flush();

        $serie = $episode->getSeason()->getPoster();
        $downloads = 0;
        foreach ($serie->getSeasons() as $key => $season) {
            foreach ($season->getEpisodes() as $key => $value) {
                $downloads += $value->getDownloads();
            }
        }
        $serie->setDownloads($downloads);
        $em->flush();

        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent = $serializer->serialize($episode->getDownloads(), 'json');
        return new Response($jsonContent);
    }
    public function delete($id,Request $request) : Response
    {
        $em=$this->getDoctrine()->getManager();

        $episode = $em->getRepository("App\Admin\Entity\Episode")->find($id);
        if($episode==null){
            throw new NotFoundHttpException("Page not found");
        }
        
        $season=$episode->getSeason();
            $url = $this->generateUrl('app_admin_serie_seasons',array("id"=>$season->getPoster()->getId()));
            foreach ($episode->getTorrents() as $key => $torrent) {
                $em->remove($torrent);
                $em->flush();
            }
            foreach ($episode->getSubtitles() as $key => $subtitle) {
                $media_subtitle = $subtitle->getMedia();
                
                $em->remove($subtitle);
                $em->flush();

                if ($media_subtitle!=null) {
                    $media_subtitle->delete($this->getParameter('files_directory'));
                    $em->remove($media_subtitle);
                    $em->flush();
                }
            }
            $media_episode = $episode->getMedia();

            $em->remove($episode);
            $em->flush();

            if ($media_episode!=null) {
                $media_episode->delete($this->getParameter('files_directory'));
                $em->remove($media_episode);
                $em->flush();
            }

            $serie = $season->getPoster();
            $views = 0;

            foreach ($serie->getSeasons() as $key_s => $c_session) {
                foreach ($c_session->getEpisodes() as $key_c => $c_episode) {
                    $views += $c_episode->getViews();
                }
            }
            
            $serie->setViews($views);
            $em->flush();

            $episodes =  $em->getRepository("App\Admin\Entity\Episode")->findBy(array("season"=>$season),array("position"=>"asc"));
            $position = 0;
            foreach ($episodes as $key => $ep) {
                $position ++;
                $ep->setPosition($position);
                $em->flush();
            }

            $this->addFlash('success', 'Operation has been done successfully');
            return $this->redirect($url);
        
    }

}
?>