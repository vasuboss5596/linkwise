<?php
namespace App\Admin\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use \Liip\ImagineBundle\Imagine\Cache\CacheManager;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;
class HomeController  extends AbstractController
{
    public function index(): Response
    {



        $start = new \DateTime;
        $start->setDate($start->format('Y'), $start->format('n'), 1); // Normalize the day to 1
        $start->setTime(0, 0, 0); // Normalize time to midnight
        $start->sub(new \DateInterval('P12M'));
        $interval = new \DateInterval('P1M');
        $recurrences = 12;
        $date_list  = array(); 
        foreach (new \DatePeriod($start, $interval, $recurrences, true) as $date) {
            $date_list[] =  $date; // attempting to make it more clear to read here
        }
        $date_list = array_reverse($date_list);


        $new = new \DateTime;

        $year_user = $new->format("Y");
        $month_user = $new->format("m");
        $_selected_user= 0;
        if (isset($_GET["date_user"])) {
            $year_user = $date_list[$_GET["date_user"]]->format("Y");
            $month_user = $date_list[$_GET["date_user"]]->format("m");
            $_selected_user= $_GET["date_user"];
        }
        $em = $this->getDoctrine()->getManager();
        $result_ = $em->getRepository("App\Auth\Entity\User")
        ->createQueryBuilder('visiteur')
        ->select('DAY(visiteur.created) AS date_, count(visiteur) as count_')
        ->where("YEAR(visiteur.created) = ".$year_user,"MONTH(visiteur.created) = ".$month_user)
        ->groupBy('date_')
        ->getQuery()
        ->getResult();  

        $year_earning = $new->format("Y");
        $month_earning = $new->format("m");
        $_selected_earning= 0;
        if (isset($_GET["date_earning"])) {
            $year_earning = $date_list[$_GET["date_earning"]]->format("Y");
            $month_earning = $date_list[$_GET["date_earning"]]->format("m");
            $_selected_earning= $_GET["date_earning"];
        }


        $result_earnings = $em->getRepository("App\Admin\Entity\Subscription")
        ->createQueryBuilder('subscription')
        ->select('DAY(subscription.created) AS date_, sum(subscription.price) as count_')
        ->where("YEAR(subscription.created) = ".$year_earning,"MONTH(subscription.created) = ".$month_earning,"subscription.status like 'paid'")
        ->groupBy('date_')
        ->getQuery()
        ->getResult();  

        for ($i=1; $i <= cal_days_in_month(CAL_GREGORIAN, $month_user, $year_user); $i++) { 
            $line_exist = false;
            foreach ($result_ as $key => $value) {
                if ($value["date_"] == $i) {
                    $line_exist=true;
                    $result_users[$i]=$value;
                }
            }
            if (!$line_exist == true) {
               
                $new_= array();
                $new_["date_"]=$i;
                $new_["count_"]=0;
                $result_users[$i]=$new_;
            }
            
        }

        
        for ($i=1; $i <= cal_days_in_month(CAL_GREGORIAN, $month_earning, $year_earning); $i++) { 
            $line_exist = false;
            foreach ($result_earnings as $key => $value) {
                if ($value["date_"] == $i) {
                    $line_exist=true;
                    $result_earnings_final[$i]=$value;
                }
            }
            if (!$line_exist == true) {
               
                $new_= array();
                $new_["date_"]=$i;
                $new_["count_"]=0;
                $result_earnings_final[$i]=$new_;
            }
            
        }

        $actors=$em->getRepository('App\Admin\Entity\Actor')->count(array());
        $slides=$em->getRepository('App\Admin\Entity\Slide')->count(array());
        $messages=$em->getRepository('App\Admin\Entity\Support')->count(array());

        $genres=$em->getRepository('App\Admin\Entity\Genre')->count(array());
        $users=$em->getRepository('App\Auth\Entity\User')->count(array());
        $movies=$em->getRepository('App\Admin\Entity\Poster')->count(array("type"=>"movie"));
        $movies_downloads=$em->getRepository('App\Admin\Entity\Poster')->countMoviesDownloads();
        $movies_shares=$em->getRepository('App\Admin\Entity\Poster')->countMoviesShares();
        $movies_views=$em->getRepository('App\Admin\Entity\Poster')->countMoviesViews();
        $series_downloads=$em->getRepository('App\Admin\Entity\Poster')->countSeriesDownloads();
        $series_views=$em->getRepository('App\Admin\Entity\Poster')->countSeriesViews();
        $series_shares=$em->getRepository('App\Admin\Entity\Poster')->countSeriesShares();
        $series=$em->getRepository('App\Admin\Entity\Poster')->count(array("type"=>"serie"));
        $comments=$em->getRepository('App\Admin\Entity\Comment')->count(array());
        $ratings=$em->getRepository('App\Admin\Entity\Rating')->count(array());
        $subscriptions=$em->getRepository('App\Admin\Entity\Subscription')->count(array());
        $plans=$em->getRepository('App\Admin\Entity\Plan')->count(array());
        $coupons=$em->getRepository('App\Admin\Entity\Coupon')->count(array());
        $ratings=$em->getRepository('App\Admin\Entity\Rating')->count(array());
        $settings=$em->getRepository('App\Admin\Entity\Settings')->findOneBy(array());

        return $this->render("Admin/Home/index.html.twig",[
            "users"=>$users,

            "movies"=>$movies,
            "movies_downloads"=>$movies_downloads,
            "movies_shares"=>$movies_shares,
            "movies_views"=>$movies_views,

            "series"=>$series,
            "series_downloads"=>$series_downloads,
            "series_shares"=>$series_shares,
            "series_views"=>$series_views,
            "comments"=>$comments,
            "ratings"=>$ratings,
            "subscriptions"=>$subscriptions,
            "genres"=>$genres,
            "actors"=>$actors,
            "slides"=>$slides,
            "messages"=>$messages,
            "result_users"=>$result_users,
            "result_earnings_final"=>$result_earnings_final,
            "currency"=>$settings->getCurrency(),
            "date_list"=>$date_list,
            "_selected_user"=>$_selected_user,
            "_selected_earning"=>$_selected_earning,
            "plans"=>$plans,
            "coupons"=>$coupons,
            "ratings"=>$ratings
        ]);
    }

    public function api_check(Request $request, $token,CacheManager $imagineCacheManager) : Response{
            
            $id=$request->get("id");
            $key=$request->get("key");
            $device=$request->get("device");

            sleep(2);

            $code=500;
            $message="";
            $values=array();
            if ($token!=$this->getParameter('token_app')) {
                $code=500;
            }

            $em = $this->getDoctrine()->getManager();
            $user=$em->getRepository('App\Auth\Entity\User')->findOneBy(array("id"=>$id));
            $settings=$em->getRepository('App\Admin\Entity\Settings')->findOneBy(array());

            if($user){
                if ($user->isEnabled()) {
                    if ($key==sha1($user->getPassword())) {
                        $code=400;
                        $session=$em->getRepository('App\Auth\Entity\Session')->findOneBy(array("user"=>$user,"device"=>$device));
                        $code =  ($session == null)? 400:200;
                    }else{
                        $code=400;
                    }
                }else{
                    $code=300;
                }
                if ($user->hasRole("ROLE_ADMIN")) {
                    $code=400;
                }
            }else{
                $code=400;
            }
            $values[]=array("name"=>"LOGIN","value"=>($settings->getLogin())?"TRUE":"FALSE"); 


            $settings =   $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());

            $response_ads_rewarded["name"] = "ADMIN_REWARDED_ADMOB_ID";
            $response_ads_rewarded["value"] = $settings->getRewardedid();

            $response_ads_rewarded_type["name"] = "ADMIN_REWARDED_AD_TYPE";
            $response_ads_rewarded_type["value"] = $settings->getRewardedtype();

            $response_ads_interstitial_admob_id["name"] = "ADMIN_INTERSTITIAL_ADMOB_ID";
            $response_ads_interstitial_admob_id["value"] = $settings->getInterstitialid();
            


            $response_ads_interstitial_type["name"] = "ADMIN_INTERSTITIAL_TYPE";
            $response_ads_interstitial_type["value"] = $settings->getInterstitialtype();

            $response_ads_interstitial_click["name"] = "ADMIN_INTERSTITIAL_CLICKS";
            $response_ads_interstitial_click["value"] = $settings->getInterstitialclick();

            $response_ads_banner_admob_id["name"] = "ADMIN_BANNER_ADMOB_ID";
            $response_ads_banner_admob_id["value"] = $settings->getBannerid();


            $response_ads_banner_type["name"] = "ADMIN_BANNER_TYPE";
            $response_ads_banner_type["value"] = $settings->getBannertype();


            $response_ads_native_admob_id["name"] = "ADMIN_NATIVE_ADMOB_ID";
            $response_ads_native_admob_id["value"] = $settings->getNativeid();

            $response_ads_native_item["name"] = "ADMIN_NATIVE_LINES";
            $response_ads_native_item["value"] = $settings->getNativeitem();


            $response_ads_native_type["name"] = "ADMIN_NATIVE_TYPE";
            $response_ads_native_type["value"] = $settings->getNativetype();


            $response_currency["name"] = "APP_CURRENCY";
            $response_currency["value"] = $settings->getCurrency();


            $response_cash_account["name"] = "APP_CASH_ACCOUNT";
            $response_cash_account["value"] = $settings->getCashaccount();

            $response_stripe_public_key["name"] = "APP_STRIPE_PUBLIC_KEY";
            $response_stripe_public_key["value"] = $settings->getStripepublickey();


            $response_stripe_enabled["name"] = "APP_STRIPE_ENABLED";
            $response_stripe_enabled["value"] = ($settings->getStripe())? "TRUE":"FALSE";

            $response_paypal_enabled["name"] = "APP_PAYPAL_ENABLED";
            $response_paypal_enabled["value"] = ($settings->getPaypal())? "TRUE":"FALSE";


            $response_paypal_client_id["name"] = "APP_PAYPAL_CLIENT_ID";
            $response_paypal_client_id["value"] = $settings->getPaypalclientid();


            $response_cash_enabled["name"] = "APP_CASH_ENABLED";
            $response_cash_enabled["value"] = ($settings->getManual())? "TRUE":"FALSE";

            $response_gplay_enabled["name"] = "APP_GPLAY_ENABLED";
            $response_gplay_enabled["value"] = ($settings->getGpay())? "TRUE":"FALSE";


            $response_app_login_required["name"] = "APP_LOGIN_REQUIRED";
            $response_app_login_required["value"] = ($settings->getLogin())? "TRUE":"FALSE";




            $values[]=$response_ads_rewarded;
            $values[]=$response_ads_rewarded_type;
            
            $values[]=$response_ads_interstitial_admob_id;
            $values[]=$response_ads_interstitial_type;
            $values[]=$response_ads_interstitial_click;
            $values[]=$response_ads_banner_admob_id;
            $values[]=$response_ads_banner_type;
            $values[]=$response_ads_native_admob_id;
            $values[]=$response_ads_native_item;
            $values[]=$response_ads_native_type;
            $values[]=$response_currency;
            $values[]=$response_cash_account;
            $values[]=$response_stripe_public_key;
            $values[]=$response_stripe_enabled;
            $values[]=$response_paypal_enabled;
            $values[]=$response_cash_enabled;
            $values[]=$response_gplay_enabled;
            $values[]=$response_app_login_required;
            $values[]=$response_paypal_client_id;


            $error=array(
                "code"=>$code,
                "message"=>$message,
                "values"=>$values
            );
            $encoders = array(new XmlEncoder(), new JsonEncoder());
            $normalizers = array(new ObjectNormalizer());
            $serializer = new Serializer($normalizers, $encoders);
            $jsonContent=$serializer->serialize($error, 'json');
            return new Response($jsonContent);

    }
    public function api_first(Request $request, $token,CacheManager $imagineCacheManager) : Response{
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $em = $this->getDoctrine()->getManager();
        $slides = $em->getRepository("App\Admin\Entity\Slide")->findBy(array(), array("position" => "asc"));
        $genres = $em->getRepository("App\Admin\Entity\Genre")->findBy(array(), array("position" => "asc"));
        $popular = $em->getRepository("App\Admin\Entity\Poster")->findBy(array("enabled"=>true), array("views" => "desc"),20);
        $bestrated = $em->getRepository("App\Admin\Entity\Poster")->findBy(array("enabled"=>true), array("rating" => "desc"),10);


        $repository = $em->getRepository('App\Admin\Entity\Actor');

        $query = $repository->createQueryBuilder('A')
            ->select(array("A.id","A.name","A.type","A.born","A.height","A.bio","m.url as image","m.extension as extension","SUM(P.views) as test"))
            ->leftJoin('A.roles', 'G')
            ->leftJoin('G.poster', 'P')
            ->leftJoin('A.media', 'm')
            ->groupBy('A.id')
            ->orderBy('test',"DESC")
            ->setMaxResults(10)
            ->getQuery();


        $actors = $query->getResult();


        $obj;


        $actors_list=array();
        foreach ($actors as $key => $actor) {
                  $actor_obj["id"]=$actor["id"];
                  $actor_obj["type"]=$actor["type"];
                  $actor_obj["name"]=$actor["name"];
                  $actor_obj["bio"]=$actor["bio"];
                  $actor_obj["height"]=$actor["height"];
                  $actor_obj["born"]=$actor["born"];
            $actor_obj["image"] = $imagineCacheManager->getBrowserPath("uploads/".$actor["extension"]."/".$actor["image"], 'thumb_500');
            $actors_list[]=$actor_obj;
        }

        $slides_list =  array();

        $obj["actors"]=$actors_list;

        foreach ($slides as $key => $slide) {
            $slide_obj = null;
            $slide_obj["id"]=$slide->getId();
            $slide_obj["title"]=$slide->getClear();
            $slide_obj["image"] = $imagineCacheManager->getBrowserPath($slide->getMedia()->getPath(), 'poster_thumb');

                $pstr = null;
                $pstr["id"]= $slide->getPoster()->getId();
                $pstr["title"]= $slide->getPoster()->getTitle();
                $pstr["label"]= $slide->getPoster()->getLabel();
                $pstr["sublabel"]= $slide->getPoster()->getSublabel();
                $pstr["type"]= $slide->getPoster()->getType();
                $pstr["trailer"]= $slide->getPoster()->getTrailer();
                $pstr["description"]= $slide->getPoster()->getDescription();
                $pstr["year"]= $slide->getPoster()->getYear();
                $pstr["imdb"]= $slide->getPoster()->getImdb();
                $pstr["imdbid"]= $slide->getPoster()->getImdbid();

                $pstr["rating"]= $slide->getPoster()->getRating();
                $pstr["duration"] = $slide->getPoster()->getDuration();
                $pstr["comment"] = $slide->getPoster()->getComment();
                $pstr["classification"]= $slide->getPoster()->getClassification();
                $pstr["image"] = $imagineCacheManager->getBrowserPath($slide->getPoster()->getPoster()->getPath(), 'poster_thumb');
            
                $genre_poster_list =  array();
                foreach ($slide->getPoster()->getGenres() as $key => $genre_poster) {
                    $genre_poster_obj = array();
                    $genre_poster_obj["id"]=$genre_poster->getId();
                    $genre_poster_obj["title"]=$genre_poster->getTitle();
                    $genre_poster_list[] = $genre_poster_obj;
                }
                $pstr["genres"] = $genre_poster_list;


                $torrent_list =  array();
                foreach ($slide->getPoster()->getTorrents() as $key => $torrent) {
                    $torrent_obj = array();
                    $torrent_obj["id"]=$torrent->getId();
                    $torrent_obj["title"]=$torrent->getTitle();
                    $torrent_obj["quality"]=$torrent->getQuality();
                    $torrent_obj["size"]=$torrent->getSize();
                    $torrent_obj["leechers"]=$torrent->getLeechers();
                    $torrent_obj["seeders"]=$torrent->getSeeders();
                    $torrent_obj["premium"]=$torrent->getPremium();
                    $torrent_obj["url"]=$torrent->getUrl();
                
                    $torrent_list[] = $torrent_obj;
                }
                $pstr["torrents"] = $torrent_list;
                $slide_obj["poster"]= $pstr;
            
            $slides_list[]=$slide_obj;
        }
        $obj["slides"]=$slides_list;



        $genre_obj["id"]=-1;
        $genre_obj["title"]="Top Rated ";
        $posters = array();

        foreach ($bestrated as $key => $poster) {
                $pstr = null;
                $pstr["id"]= $poster->getId();
                $pstr["title"]= $poster->getTitle();
                $pstr["label"]= $poster->getLabel();
                $pstr["sublabel"]= $poster->getSublabel();
                $pstr["type"]= $poster->getType();
                $pstr["description"]= $poster->getDescription();
                $pstr["year"]= $poster->getYear();
                $pstr["imdb"]= $poster->getImdb();
                $pstr["imdbid"]= $poster->getImdbid();
                $pstr["rating"]= $poster->getRating();
                $pstr["comment"]= $poster->getComment();
                $pstr["duration"] = $poster->getDuration(); 
                $pstr["classification"]= $poster->getClassification();
                $pstr["image"] = $imagineCacheManager->getBrowserPath($poster->getPoster()->getPath(), 'poster_thumb');
                $pstr["trailer"]= $poster->getTrailer();
                $genre_poster_list =  array();
                foreach ($poster->getGenres() as $key => $genre_poster) {
                    $genre_poster_obj = array();
                    $genre_poster_obj["id"]=$genre_poster->getId();
                    $genre_poster_obj["title"]=$genre_poster->getTitle();
                    $genre_poster_list[] = $genre_poster_obj;
                }
                $pstr["genres"] = $genre_poster_list;



                $torrent_list =  array();
                foreach ($poster->getTorrents() as $key => $torrent) {
                    $torrent_obj = array();
                    $torrent_obj["id"]=$torrent->getId();
                    $torrent_obj["title"]=$torrent->getTitle();
                    $torrent_obj["quality"]=$torrent->getQuality();
                    $torrent_obj["size"]=$torrent->getSize();
                    $torrent_obj["leechers"]=$torrent->getLeechers();
                    $torrent_obj["seeders"]=$torrent->getSeeders();
                    $torrent_obj["premium"]=$torrent->getPremium();
                    $torrent_obj["url"]=$torrent->getUrl();
                
                    $torrent_list[] = $torrent_obj;
                }
                $pstr["torrents"] = $torrent_list;

                $posters[]=$pstr;
            

        }
        $genre_obj["posters"] = $posters;
        $genres_list[]=$genre_obj;
        $genre_obj = null;
        $genre_obj["id"]=0;
        $genre_obj["title"]="Popular";
        $posters = array();
        foreach ($popular as $key => $poster) {
                $pstr = null;
                $pstr["id"]= $poster->getId();
                $pstr["title"]= $poster->getTitle();
                $pstr["label"]= $poster->getLabel();
                $pstr["sublabel"]= $poster->getSublabel();
                $pstr["type"]= $poster->getType();
                $pstr["imdb"]= $poster->getImdb();
                $pstr["imdbid"]= $poster->getImdbid();
                $pstr["description"]= $poster->getDescription();
                $pstr["year"]= $poster->getYear();
                $pstr["comment"]= $poster->getComment();
                $pstr["rating"]= $poster->getRating();
                $pstr["duration"] = $poster->getDuration();
                $pstr["classification"]= $poster->getClassification();
                $pstr["image"] = $imagineCacheManager->getBrowserPath($poster->getPoster()->getPath(), 'poster_thumb');
                $pstr["trailer"]= $poster->getTrailer();
                $genre_poster_list =  array();
                foreach ($poster->getGenres() as $key => $genre_poster) {
                    $genre_poster_obj = array();
                    $genre_poster_obj["id"]=$genre_poster->getId();
                    $genre_poster_obj["title"]=$genre_poster->getTitle();
                    $genre_poster_list[] = $genre_poster_obj;
                }
                $pstr["genres"] = $genre_poster_list;



                $torrent_list =  array();
                foreach ($poster->getTorrents() as $key => $torrent) {
                    $torrent_obj = array();
                    $torrent_obj["id"]=$torrent->getId();
                    $torrent_obj["title"]=$torrent->getTitle();
                    $torrent_obj["quality"]=$torrent->getQuality();
                    $torrent_obj["size"]=$torrent->getSize();
                    $torrent_obj["leechers"]=$torrent->getLeechers();
                    $torrent_obj["seeders"]=$torrent->getSeeders();
                    $torrent_obj["premium"]=$torrent->getPremium();
                    $torrent_obj["url"]=$torrent->getUrl();
                
                    $torrent_list[] = $torrent_obj;
                }
                $pstr["torrents"] = $torrent_list;

                $posters[]=$pstr;
            

        }
        $genre_obj["posters"] = $posters;
        $genres_list[]=$genre_obj;

        foreach ($genres as $key => $genre) {
            $genre_obj = null;
            $genre_obj["id"]=$genre->getId();
            $genre_obj["title"]=$genre->getTitle();
            $posters = array();
            $count = 0;
            foreach ($genre->getPosters() as $key => $poster) {
                if ($count<15 && $poster->getEnabled()) {
                    $count++;
                    $pstr = null;
                    $pstr["id"]= $poster->getId();
                    $pstr["title"]= $poster->getTitle();
                    $pstr["label"]= $poster->getLabel();
                    $pstr["sublabel"]= $poster->getSublabel();
                    $pstr["type"]= $poster->getType();
                    $pstr["description"]= $poster->getDescription();
                    $pstr["year"]= $poster->getYear();
                    $pstr["rating"]= $poster->getRating();
                    $pstr["comment"]= $poster->getComment();
                    $pstr["imdb"]= $poster->getImdb();
                    $pstr["imdbid"]= $poster->getImdbid();
                    $pstr["duration"] = $poster->getDuration();
                    
                    $pstr["classification"]= $poster->getClassification();
                    $pstr["image"] = $imagineCacheManager->getBrowserPath($poster->getPoster()->getPath(), 'poster_thumb');
                    $pstr["trailer"]= $poster->getTrailer();
                    $genre_poster_list =  array();
                    foreach ($poster->getGenres() as $key => $genre_poster) {
                        $genre_poster_obj = array();
                        $genre_poster_obj["id"]=$genre_poster->getId();
                        $genre_poster_obj["title"]=$genre_poster->getTitle();
                        $genre_poster_list[] = $genre_poster_obj;
                    }
                    $pstr["genres"] = $genre_poster_list;




                $torrent_list =  array();
                foreach ($poster->getTorrents() as $key => $torrent) {
                    $torrent_obj = array();
                    $torrent_obj["id"]=$torrent->getId();
                    $torrent_obj["title"]=$torrent->getTitle();
                    $torrent_obj["quality"]=$torrent->getQuality();
                    $torrent_obj["size"]=$torrent->getSize();
                    $torrent_obj["leechers"]=$torrent->getLeechers();
                    $torrent_obj["seeders"]=$torrent->getSeeders();
                    $torrent_obj["premium"]=$torrent->getPremium();
                    $torrent_obj["url"]=$torrent->getUrl();
                
                    $torrent_list[] = $torrent_obj;
                }
                $pstr["torrents"] = $torrent_list;

                $posters[]=$pstr;

                }

            }
            $genre_obj["posters"] = $posters;
            $genres_list[]=$genre_obj;

        }
        $obj["genres"]=$genres_list;

        $response = new Response();
        $response->setContent(json_encode(
            $obj
        ));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }
   
}
?>