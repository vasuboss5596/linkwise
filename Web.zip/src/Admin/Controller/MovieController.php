<?php 
namespace App\Admin\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Admin\Entity\Poster;
use App\Admin\Entity\Genre;
use App\Admin\Entity\Rating;
use App\Admin\Entity\Role;
use App\Admin\Entity\Actor;
use App\Admin\Entity\Item;

use App\Admin\Entity\Subtitle;
use App\Media\Entity\Media;
use App\Admin\Form\MovieType;

use App\Admin\Form\SubtitleType;
use App\Admin\Form\RoleType;
use App\Admin\Form\SourceType;
use App\Admin\Form\EditMovieType;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Knp\Component\Pager\PaginatorInterface;
use App\Admin\Entity\Torrent;
use \Liip\ImagineBundle\Imagine\Cache\CacheManager;

use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class MovieController extends AbstractController

{
    public function api_by_id(Request $request,$id,CacheManager $imagineCacheManager) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $poster=$em->getRepository("App\Admin\Entity\Poster")->find($id);
        if ($poster==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $pstr = null;
        $pstr["id"]= $poster->getId();
        $pstr["title"]= $poster->getTitle();
        $pstr["label"]= $poster->getLabel();
        $pstr["sublabel"]= $poster->getSublabel();
        $pstr["type"]= $poster->getType();
        $pstr["imdb"]= $poster->getImdb();
        $pstr["imdbid"]= $poster->getImdbid();
        $pstr["description"]= $poster->getDescription();
        $pstr["year"]= $poster->getYear();
        $pstr["comment"]= $poster->getComment();
        $pstr["rating"]= $poster->getRating();
        $pstr["duration"] = $poster->getDuration();
        $pstr["classification"]= $poster->getClassification();
        $pstr["image"] = $imagineCacheManager->getBrowserPath($poster->getPoster()->getPath(), 'poster_thumb');
        $pstr["trailer"]= $poster->getTrailer();
        $genre_poster_list =  array();
        foreach ($poster->getGenres() as $key => $genre_poster) {
            $genre_poster_obj = array();
            $genre_poster_obj["id"]=$genre_poster->getId();
            $genre_poster_obj["title"]=$genre_poster->getTitle();
            $genre_poster_list[] = $genre_poster_obj;
        }
        $pstr["genres"] = $genre_poster_list;



        $torrent_list =  array();
        foreach ($poster->getTorrents() as $key => $torrent) {
            $torrent_obj = array();
            $torrent_obj["id"]=$torrent->getId();
            $torrent_obj["title"]=$torrent->getTitle();
            $torrent_obj["quality"]=$torrent->getQuality();
            $torrent_obj["size"]=$torrent->getSize();
            $torrent_obj["leechers"]=$torrent->getLeechers();
            $torrent_obj["seeders"]=$torrent->getSeeders();
            $torrent_obj["premium"]=$torrent->getPremium();
            $torrent_obj["url"]=$torrent->getUrl();
        
            $torrent_list[] = $torrent_obj;
        }
        $pstr["torrents"] = $torrent_list;


        $response = new Response();
        $response->setContent(json_encode(
            $pstr
        ));
        $response->headers->set('Content-Type', 'application/json');
        return $response;

    }
    public function api_add_view(Request $request, $token) : Response
    {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $em = $this->getDoctrine()->getManager();
        $id = $request->get("id");
        $poster = $em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"enabled"=>true));
        if ($poster == null) {
            throw new NotFoundHttpException("Page not found");
        }
        $poster->setViews($poster->getViews() + 1);
        $em->flush();
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent = $serializer->serialize($poster->getViews(), 'json');
        return new Response($jsonContent);
    }
    public function api_add_share(Request $request, $token) : Response
    {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $em = $this->getDoctrine()->getManager();
        $id = $request->get("id");
        $poster = $em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"enabled"=>true));
        if ($poster == null) {
            throw new NotFoundHttpException("Page not found");
        }
        $poster->setShares($poster->getShares() + 1);
        $em->flush();
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent = $serializer->serialize($poster->getShares(), 'json');
        return new Response($jsonContent);
    }
    public function api_add_download(Request $request, $token) : Response
    {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $em = $this->getDoctrine()->getManager();
        $id = $request->get("id");
        $poster = $em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"enabled"=>true));
        if ($poster == null) {
            throw new NotFoundHttpException("Page not found");
        }
        $poster->setDownloads($poster->getDownloads() + 1);
        $em->flush();
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent = $serializer->serialize($poster->getDownloads(), 'json');
        return new Response($jsonContent);
    }
    
    public function api_poster_by_genre(Request $request, $genre,$order,$page, $token,CacheManager $imagineCacheManager) : Response
    {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $nombre = 30;
        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App\Admin\Entity\Poster');
        $dir = "DESC";
        if("title"==$order){
            $dir="ASC";
        }

        if($genre==0 or $genre == -1){
            $query = $repository->createQueryBuilder('p')
                ->where("p.enabled = true")
                ->addOrderBy('p.'.$order, $dir)
                ->addOrderBy('p.id', 'ASC')
                ->setFirstResult($nombre * $page)
                ->setMaxResults($nombre)
                ->getQuery();         
        }else{
            $query = $repository->createQueryBuilder('p')
                ->leftJoin('p.genres', 'g')
                ->where("p.enabled = true",'g.id = ' . $genre)
                ->addOrderBy('p.'.$order, $dir)
                ->addOrderBy('p.id', 'ASC')
                ->setFirstResult($nombre * $page)
                ->setMaxResults($nombre)
                ->getQuery();         
        }  
        $posters_list = $query->getResult();
        $posters_list =   $this->moviesToJson($posters_list,$imagineCacheManager);


        $response = new Response();
        $response->setContent(json_encode(
            $posters_list
        ));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    public function api_search(Request $request, $query,$page,$order, $token,CacheManager $imagineCacheManager) : Response
    {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }

        $nombre = 30;
        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App\Admin\Entity\Poster');
        $query = strtolower($query);
        $where = "";
        if($query != null )
            $where.=" LOWER(p.title) like '%" . $query . "%' or LOWER(p.tags) like '%" . $query . "%'";

        $dir = "DESC";

        if("title"==$order){
            $dir="ASC";
        }


         $query = $repository->createQueryBuilder('p')
            
                ->where("p.enabled = true",$where)
                ->addOrderBy('p.'.$order, $dir)
                ->addOrderBy('p.id', 'ASC')
                ->setFirstResult($nombre * $page)
                ->setMaxResults($nombre)
                ->getQuery();         
        
        $posters_list = $query->getResult();
        $posters_list =   $this->moviesToJson($posters_list,$imagineCacheManager);


        $response = new Response();
        $response->setContent(json_encode(
            $posters_list
        ));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }
    public function api_by_filter(Request $request, $genre, $year,$order,$page, $token,CacheManager $imagineCacheManager) : Response
    {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }

        $nombre = 30;
        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App\Admin\Entity\Poster');
        $dir = "DESC";

        if("title"==$order){
            $dir="ASC";
        }
        $where = "1 = 1";
        
        if($year != 0)
            $where.=" AND p.year = ".$year;
        
        if($genre!=0){
             $where.=" AND g.id = ".$genre;   
             $query = $repository->createQueryBuilder('p')
                ->leftJoin('p.genres', 'g')
                ->where("p.enabled = true","p.type like 'movie' ",$where)
                ->addOrderBy('p.'.$order, $dir)
                ->addOrderBy('p.id', 'ASC')
                ->setFirstResult($nombre * $page)
                ->setMaxResults($nombre)
                ->getQuery();     
        }else{
            $query = $repository->createQueryBuilder('p')
                ->where("p.enabled = true","p.type like 'movie' ",$where)
                ->addOrderBy('p.'.$order, $dir)
                ->addOrderBy('p.id', 'ASC')
                ->setFirstResult($nombre * $page)
                ->setMaxResults($nombre)
                ->getQuery();     
       }    
               
        
        $posters_list = $query->getResult();
        $posters_list =   $this->moviesToJson($posters_list,$imagineCacheManager);


        $response = new Response();
        $response->setContent(json_encode(
            $posters_list
        ));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    public function api_related(Request $request, $genres, $token,CacheManager $imagineCacheManager) : Response
    {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $nombre = 30;
        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App\Admin\Entity\Poster');
        $query = $repository->createQueryBuilder('p')
            ->leftJoin('p.genres', 'g')
            ->where("p.enabled = true","p.type like 'movie' ",'g.id in (' . $genres . ')')
            ->addSelect('RAND() as HIDDEN rand')
            ->orderBy('rand')
            ->setMaxResults($nombre)
            ->getQuery();
        $posters_list = $query->getResult();

        $posters_list =   $this->moviesToJson($posters_list,$imagineCacheManager);


        $response = new Response();
        $response->setContent(json_encode(
            $posters_list
        ));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }
    public function moviesToJson($list,$imagineCacheManager){
        $posters = array();
        foreach ($list as $key => $poster) {
                $pstr = null;
                $pstr["id"]= $poster->getId();
                $pstr["title"]= $poster->getTitle();
                $pstr["label"]= $poster->getLabel();
                $pstr["sublabel"]= $poster->getSublabel();
                $pstr["type"]= $poster->getType();
                $pstr["imdb"]= $poster->getImdb();
                $pstr["imdbid"]= $poster->getImdbid();
                $pstr["description"]= $poster->getDescription();
                $pstr["year"]= $poster->getYear();
                $pstr["comment"]= $poster->getComment();
                $pstr["rating"]= $poster->getRating();
                $pstr["duration"] = $poster->getDuration();
                $pstr["classification"]= $poster->getClassification();
                $pstr["image"] = $imagineCacheManager->getBrowserPath($poster->getPoster()->getPath(), 'poster_thumb');
                $pstr["trailer"]= $poster->getTrailer();
                $genre_poster_list =  array();
                foreach ($poster->getGenres() as $key => $genre_poster) {
                    $genre_poster_obj = array();
                    $genre_poster_obj["id"]=$genre_poster->getId();
                    $genre_poster_obj["title"]=$genre_poster->getTitle();
                    $genre_poster_list[] = $genre_poster_obj;
                }
                $pstr["genres"] = $genre_poster_list;



                $torrent_list =  array();
                foreach ($poster->getTorrents() as $key => $torrent) {
                    $torrent_obj = array();
                    $torrent_obj["id"]=$torrent->getId();
                    $torrent_obj["title"]=$torrent->getTitle();
                    $torrent_obj["quality"]=$torrent->getQuality();
                    $torrent_obj["size"]=$torrent->getSize();
                    $torrent_obj["leechers"]=$torrent->getLeechers();
                    $torrent_obj["seeders"]=$torrent->getSeeders();
                    $torrent_obj["premium"]=$torrent->getPremium();
                    $torrent_obj["url"]=$torrent->getUrl();
                
                    $torrent_list[] = $torrent_obj;
                }
                $pstr["torrents"] = $torrent_list;

                $posters[]=$pstr;
            
        }
        return $posters;
    }
    public function api_by_actor(Request $request, $id, $token,CacheManager $imagineCacheManager) : Response
    {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $nombre = 30;
        $em = $this->getDoctrine()->getManager();
        $repository = $em->getRepository('App\Admin\Entity\Poster');
        $query = $repository->createQueryBuilder('p')
            ->leftJoin('p.roles', 'r')
            ->leftJoin('r.actor', 'u')
            ->where("p.enabled = true","u.id  = ".$id)
            ->addOrderBy('p.created', 'DESC')
            ->addOrderBy('p.id', 'ASC')
            ->setMaxResults($nombre)
            ->getQuery();
        $posters_list = $query->getResult();
        $posters_list =   $this->moviesToJson($posters_list,$imagineCacheManager);


        $response = new Response();
        $response->setContent(json_encode(
            $posters_list
        ));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    public function index(Request $request,PaginatorInterface $paginator) : Response
    {

        $em = $this->getDoctrine()->getManager();
        $q = " ";
        if ($request->query->has("q") and $request->query->get("q") != "") {
            $q .= " AND  p.title like '%" . $request->query->get("q") . "%'";
        }

        $dql = "SELECT p FROM App\Admin\Entity\Poster p  WHERE  p.type  like 'movie' " . $q . " ORDER BY p.created desc ";
        $query = $em->createQuery($dql);
        $movies = $paginator->paginate(
            $query,
            $request->query->getInt('page', 1),
            16
        );
        $movies_count = $em->getRepository('App\Admin\Entity\Poster')->countMovies();
        return $this->render('Admin/Movie/index.html.twig', array("movies_count" => $movies_count, "movies" => $movies));
    }
    /*function get_image_mime_type($image_path)
    {
        $mimes  = array(
            IMAGETYPE_GIF => "image/gif",
            IMAGETYPE_JPEG => "image/jpg",
            IMAGETYPE_PNG => "image/png",
            IMAGETYPE_SWF => "image/swf",
            IMAGETYPE_PSD => "image/psd",
            IMAGETYPE_BMP => "image/bmp",
            IMAGETYPE_TIFF_II => "image/tiff",
            IMAGETYPE_TIFF_MM => "image/tiff",
            IMAGETYPE_JPC => "image/jpc",
            IMAGETYPE_JP2 => "image/jp2",
            IMAGETYPE_JPX => "image/jpx",
            IMAGETYPE_JB2 => "image/jb2",
            IMAGETYPE_SWC => "image/swc",
            IMAGETYPE_IFF => "image/iff",
            IMAGETYPE_WBMP => "image/wbmp",
            IMAGETYPE_XBM => "image/xbm",
            IMAGETYPE_ICO => "image/ico");

        if (($image_type = exif_imagetype($image_path))
            && (array_key_exists($image_type ,$mimes)))
        {
            return $mimes[$image_type];
        }
        else
        {
            return FALSE;
        }
    }
   function get_image_ext_type($image_path)
    {
        $mimes  = array(
            IMAGETYPE_GIF => "gif",
            IMAGETYPE_JPEG => "jpg",
            IMAGETYPE_PNG => "png",
            IMAGETYPE_SWF => "swf",
            IMAGETYPE_PSD => "psd",
            IMAGETYPE_BMP => "bmp",
            IMAGETYPE_TIFF_II => "tiff",
            IMAGETYPE_TIFF_MM => "tiff",
            IMAGETYPE_JPC => "jpc",
            IMAGETYPE_JP2 => "jp2",
            IMAGETYPE_JPX => "jpx",
            IMAGETYPE_JB2 => "jb2",
            IMAGETYPE_SWC => "swc",
            IMAGETYPE_IFF => "iff",
            IMAGETYPE_WBMP => "wbmp",
            IMAGETYPE_XBM => "xbm",
            IMAGETYPE_ICO => "ico");

        if (($image_type = exif_imagetype($image_path))
            && (array_key_exists($image_type ,$mimes)))
        {
            return $mimes[$image_type];
        }
        else
        {
            return FALSE;
        }
    }
    */
    public function import_torrents(Request $request,$movie,$page) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $poster = $em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$movie));
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());


        $defaultData = array();
        $form_builder = $this->createFormBuilder($defaultData);
        $form_builder->setMethod('POST');
        $form_builder->add('id', HiddenType::class);

        $count = 0;
        $torrents=array();
        $curl_yts_infos = curl_init("https://yts.mx/api/v2/movie_details.json?imdb_id=".$poster->getImdbid());
        curl_setopt($curl_yts_infos, CURLOPT_FAILONERROR, true);
        curl_setopt($curl_yts_infos, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl_yts_infos, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl_yts_infos, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl_yts_infos, CURLOPT_SSL_VERIFYPEER, false);  
        $result_yts_infos = curl_exec($curl_yts_infos);
        $result_yts_infos_obj =  json_decode($result_yts_infos);
        if($result_yts_infos_obj->status == "ok"){
            if (property_exists($result_yts_infos_obj->data->movie, "torrents")) {
                foreach ($result_yts_infos_obj->data->movie->torrents as $key => $trnt) {
                    $count++;
                    $trnt->id = $count;
                    $trnt->title = $poster->getTitle().".".$trnt->type.".".$trnt->quality.".".$trnt->size;
                    $trnt->title= str_replace(" ","_",$trnt->title);
                    $trnt->title= strtoupper($trnt->title);
                    $torrents[]=$trnt;
                }
            }
        }

        $count_page =  $count/100;
        $count_page =  ceil($count_page);

        $form_builder->add('torrents', ChoiceType::class,array("choices"=>$torrents,                        'expanded' => true,
                        "multiple" => true,
                        'by_reference' => false,
                        'choice_label' => 'title',
                        'choice_value' => 'id',
                    )
            );
        $form = $form_builder->getForm();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            if($result_yts_infos_obj->status == "ok"){
                if (property_exists($result_yts_infos_obj->data->movie, "torrents")) {
                    foreach ($result_yts_infos_obj->data->movie->torrents as $key => $trnt) {
                       $torrent = new Torrent();
                       $torrent->setUrl("magnet:?xt=urn:btih:".$trnt->hash."&dn=".urlencode($poster->getTitle())."&tr=udp://glotorrents.pw:6969/announce&tr=udp://tracker.opentrackr.org:1337/announce&tr=udp://torrent.gresille.org:80/announce&tr=udp://tracker.openbittorrent.com:80&tr=udp://tracker.coppersurfer.tk:6969&tr=udp://tracker.leechers-paradise.org:6969&tr=udp://p4p.arenabg.ch:1337&tr=udp://tracker.internetwarriors.net:1337");
                       $torrent->setSize($trnt->size);
                       $torrent->setSeeders($trnt->seeds);
                       $torrent->setLeechers($trnt->peers);
                        $quality = "SD";
                        switch ($trnt->quality){
                            case "480p":
                                $quality = "SD";
                                break;
                            case "720p":
                                $quality = "HD";
                                break;
                            case "1080p":
                                $quality = "FHD";
                                break;
                            case "2160p":
                                $quality = "4K";
                        }

                       $torrent->setQuality($quality);
                       $torrent->setTitle($trnt->title);
                       $torrent->setPremium(1);
                       $torrent->setPoster($poster);
                       $em->persist($torrent);
                       $em->flush();
                   }
               }
               $this->addFlash('success', 'Operation has been done successfully');

               if ($page == $count_page) {
                    return $this->redirect($this->generateUrl('app_admin_movie_torrents',array("id"=>$poster->getId())));
               }else{
                    return $this->redirect($this->generateUrl('app_admin_movie_import_torrents',array("page"=>1,"movie"=>$poster->getId())));
               }
     
            }
         }
        
        return $this->render("Admin/Movie/import_torrents.html.twig",array("count_page"=>$count_page,"page"=>$page,"torrents"=>$torrents,"count"=>$count,"setting"=>$setting,"poster"=>$poster,"form"=>$form->createView()));
    }
    public function import_trailer(Request $request,$id,$movie) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $poster = $em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$movie));
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());

        $defaultData = array();
        $form = $this->createFormBuilder($defaultData)
            ->setMethod('POST')
            ->add('id', HiddenType::class)
            ->getForm();
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            $curl_trailer = curl_init("https://api.themoviedb.org/3/movie/".$id."/videos?api_key=".$setting->getThemoviedbkey()."&language=".$setting->getThemoviedblang());
            curl_setopt($curl_trailer, CURLOPT_FAILONERROR, true);
            curl_setopt($curl_trailer, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($curl_trailer, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl_trailer, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($curl_trailer, CURLOPT_SSL_VERIFYPEER, false);  
            $result_trailer = curl_exec($curl_trailer);
            $trailer_infos =  json_decode($result_trailer);
            $selected_video = null;

            foreach ($trailer_infos->results as $key => $video) {
               if ($video->type == "Trailer" and $video->site == "YouTube") {
                    $selected_video=$video;
               }
            }

            if ($selected_video !=null) {
                $poster->setTrailer("https://www.youtube.com/watch?v=".$selected_video->key);
                $em->flush();
             }    
             $this->addFlash('success', 'Operation has been done successfully');
             return $this->redirect($this->generateUrl('app_admin_movie_import_torrents',array("page"=>1,"movie"=>$poster->getId())));
     
         }
        
        return $this->render("Admin/Movie/import_trailer.html.twig",array("setting"=>$setting,"poster"=>$poster,"form"=>$form->createView()));
    }
  
    public function import_casts(Request $request,$id,$movie) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $poster = $em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$movie));
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());

        $defaultData = array();
        $form = $this->createFormBuilder($defaultData)
            ->setMethod('POST')
            ->add('id', HiddenType::class)
            ->getForm();
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            $curl_actors = curl_init("https://api.themoviedb.org/3/movie/".$id."/casts?api_key=".$setting->getThemoviedbkey()."&language=".$setting->getThemoviedblang());
            curl_setopt($curl_actors, CURLOPT_FAILONERROR, true);
            curl_setopt($curl_actors, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($curl_actors, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl_actors, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($curl_actors, CURLOPT_SSL_VERIFYPEER, false);  
            $result_actors = curl_exec($curl_actors);
            $actors_poster =  json_decode($result_actors);

            $max=0;
            $role=$em->getRepository('App\Admin\Entity\Role')->findOneBy(array("poster"=>$poster),array("position"=>"desc"));
            if ($role!=null) {
                $max = $role->getPosition();
            }
            $actors_exist = $em->getRepository('App\Admin\Entity\Actor')->findAll();
            $exist_actor = false;
            $get_actor = null;
            $count_added = 0;
            foreach ($actors_poster->cast as $key => $actor) {
                foreach ($actors_exist as $keyJ => $actor_exist) {
                    if (strtoupper($actor->name) == strtoupper($actor_exist->getName())) {
                         $exist_actor=  true;
                         $get_actor = $actor_exist;
                    }
                }
                if($exist_actor){
                    $role = new Role();
                    $role->setActor($get_actor);
                    $role->setPoster($poster);
                    $role->setRole($actor->character);
                    $max++;
                    $role->setPosition($max);
                    $em->persist($role);
                    $em->flush();                     
                }else{
                    if ($actor->profile_path != null) {
                        if ($count_added<15){
                            $curl_persone = curl_init("https://api.themoviedb.org/3/person/".$actor->id."?api_key=".$setting->getThemoviedbkey()."&language=".$setting->getThemoviedblang());
                            curl_setopt($curl_persone, CURLOPT_FAILONERROR, true);
                            curl_setopt($curl_persone, CURLOPT_FOLLOWLOCATION, true);
                            curl_setopt($curl_persone, CURLOPT_RETURNTRANSFER, true);
                            curl_setopt($curl_persone, CURLOPT_SSL_VERIFYHOST, false);
                            curl_setopt($curl_persone, CURLOPT_SSL_VERIFYPEER, false);  
                            $result_persone = curl_exec($curl_persone);
                            $persone_infos =  json_decode($result_persone);

                            $url_actor =  "https://image.tmdb.org/t/p/w400".$actor->profile_path;
                                # code...
                            
                            $actorfileName = md5(uniqid());
                            $actorfileType = "image/jpg";
                            $actorfileExt = "jpg";
                            $actorfullName = $actorfileName.".".$actorfileExt;
                            $actor_uploadTo = $this->getParameter('files_directory').$actorfileExt."/".$actorfullName;
                            
                            $arrContextOptions=array(
                                "ssl"=>array(
                                    "verify_peer"=>false,
                                    "verify_peer_name"=>false,
                                ),
                            );  


                            file_put_contents($actor_uploadTo, file_get_contents($url_actor, false, stream_context_create($arrContextOptions))); 

                            $postermedia= new Media();
                            $postermedia->setType($actorfileType);
                            $postermedia->setExtension($actorfileExt);
                            $postermedia->setUrl($actorfullName);
                            $postermedia->setTitre($actor->name);
                            $em->persist($postermedia);
                            $em->flush();

                            $newactor= new Actor();
                            $newactor->setName($actor->name);
                            if($persone_infos != null){
                                $newactor->setBio($persone_infos->biography);
                                $newactor->setBorn($persone_infos->birthday.", ".$persone_infos->place_of_birth);
                                $newactor->setType($persone_infos->known_for_department);
                                $newactor->setHeight("");
                            }else{
                                $newactor->setBio("");
                                $newactor->setBorn("");
                                $newactor->setType("");
                                $newactor->setHeight("");
                            }
                            $newactor->setMedia($postermedia);
                            $em->persist($newactor);
                            $em->flush();

                            $role = new Role();
                            $role->setActor($newactor);
                            $role->setPoster($poster);
                            $role->setRole($actor->character);
                            $max++;
                            $role->setPosition($max);
                            $em->persist($role);
                            $em->flush();
                            $count_added++;   

                        }
                    }
                }
                $exist_actor = false;
            } 

             $this->addFlash('success', 'Operation has been done successfully');
             return $this->redirect($this->generateUrl('app_admin_movie_import_trailer',array("id"=>$id,"movie"=>$poster->getId())));

        }
        return $this->render("Admin/Movie/import_casts.html.twig",array("setting"=>$setting,"poster"=>$poster,"form"=>$form->createView()));

    }
   
    public function import_keywords(Request $request,$id,$movie) : Response
    {

        $em = $this->getDoctrine()->getManager();
        $poster = $em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$movie));
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());

        $defaultData = array();
        $form = $this->createFormBuilder($defaultData)
            ->setMethod('POST')
            ->add('id', HiddenType::class)
            ->getForm();
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            $curl_keywords = curl_init("https://api.themoviedb.org/3/movie/".$id."/keywords?api_key=".$setting->getThemoviedbkey()."&language=".$setting->getThemoviedblang());
            curl_setopt($curl_keywords, CURLOPT_FAILONERROR, true);
            curl_setopt($curl_keywords, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($curl_keywords, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl_keywords, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($curl_keywords, CURLOPT_SSL_VERIFYPEER, false);  

            $result_keywords = curl_exec($curl_keywords);
            $keywords_poster =  json_decode($result_keywords);
            $keywords = "";
            foreach ($keywords_poster->keywords as $key => $keyword) {
                if ($key == 0) {
                    $keywords.=$keyword->name;
                }else{
                    $keywords.=",".$keyword->name;
                }
            }
           $poster->setTags($keywords);
           $em->flush();
             $this->addFlash('success', 'Operation has been done successfully');
             return $this->redirect($this->generateUrl('app_admin_movie_import_casts',array("id"=>$id,"movie"=>$poster->getId())));

        }
       return $this->render("Admin/Movie/import_keywords.html.twig",array("setting"=>$setting,"poster"=>$poster,"form"=>$form->createView()));

    }
    public function import(Request $request) : Response
    {

        $em=$this->getDoctrine()->getManager();
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());

        $defaultData = array();
        $form = $this->createFormBuilder($defaultData)
            ->setMethod('POST')
            ->add('id', HiddenType::class)
            ->getForm();
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $data = $form->getData();
            $id = $data["id"];
            // get Movies details 
            $curl = curl_init("https://api.themoviedb.org/3/movie/".$id."?api_key=".$setting->getThemoviedbkey()."&language=".$setting->getThemoviedblang());
            curl_setopt($curl, CURLOPT_FAILONERROR, true);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);  
            $result = curl_exec($curl);
            $detail_poster =  json_decode($result);

            $imdb_id = $detail_poster->imdb_id;
            $title = $detail_poster->title;
            $poster_path = $detail_poster->poster_path;

            $duration = $this->toTime($detail_poster->runtime);
            $description = $detail_poster->overview;
            $imdb = $detail_poster->vote_average;
            $genres = $detail_poster->genres;
            $year = substr($detail_poster->release_date, 0, 4);

            // get Movies keywords 

 
            // set Movies infos 

            $movie= new Poster();
            $movie->setTitle($title);
            $movie->setDuration($duration);
            $movie->setType("movie");
            $movie->setTags("");
            $movie->setRating("0");
            $movie->setImdb($imdb);
            $movie->setImdbid($imdb_id);
            $movie->setDescription($description);
            $movie->setDownloads(0);
            $movie->setShares(0);
            $movie->setViews(0);
            $movie->setComment(true);
            $movie->setEnabled(true);
            $movie->setYear($year);
            // get poster Movies image 

            $url =  "https://image.tmdb.org/t/p/original".$poster_path;
            $fileName = md5(uniqid());
            $fileType = "image/jpg";
            $fileExt = "jpg";
            $fullName = $fileName.".".$fileExt;

            $uploadTo = $this->getParameter('files_directory').$fileExt."/".$fullName;


                            $arrContextOptions=array(
                                "ssl"=>array(
                                    "verify_peer"=>false,
                                    "verify_peer_name"=>false,
                                ),
                            );  


            file_put_contents($uploadTo, file_get_contents($url, false, stream_context_create($arrContextOptions)));  

            $moviemedia= new Media();
            $moviemedia->setType($fileType);
            $moviemedia->setExtension($fileExt);
            $moviemedia->setUrl($fullName);
            $moviemedia->setTitre($movie->getTitle());
            $em->persist($moviemedia);
            $em->flush();
            $movie->setPoster($moviemedia);

            $genrs_exist = $em->getRepository('App\Admin\Entity\Genre')->findAll();
            $exist = false;
            $get_geren = null;
            foreach ($genres as $key => $genre) {
                foreach ($genrs_exist as $key_exist => $genre_exist) {
                    if (strtoupper($genre->name) == strtoupper($genre_exist->getTitle())) {
                         $exist=  true;
                         $get_geren = $genre_exist;
                    }
                }
                if($exist){
                     $movie->addGenre($get_geren);
                }else{
                    $last_genre = $em->getRepository('App\Admin\Entity\Genre')->findOneBy(array(),array("position"=>"desc"));
                    $new_position = ($last_genre == null)? 0 :$last_genre->getPosition()+1;
                    $newgenre= new Genre();
                    $newgenre->setTitle($genre->name);
                    $newgenre->setPosition($new_position);
                    $em->persist($newgenre);
                    $em->flush();
                    $movie->addGenre($newgenre);
                }
                $exist = false;
            }
           

            $em->persist($movie);
            $em->flush();
            
             $this->addFlash('success', 'Operation has been done successfully');
             return $this->redirect($this->generateUrl('app_admin_movie_import_keywords',array("id"=>$id,"movie"=>$movie->getId())));

        }
       return $this->render("Admin/Movie/import.html.twig",array("setting"=>$setting,"form"=>$form->createView()));
    }
    public function toTime($final_time_saving){
        $hours = floor($final_time_saving / 60);
        $minutes = $final_time_saving % 60;
        $time = "";
        if ($hours!=0) {
            $time =$hours."h ";
        }
        $time.=$minutes."min";
        return $time;
    }
    public function add(Request $request) : Response
    {



        $movie= new Poster();
        $form = $this->createForm(MovieType::class,$movie);
        $em=$this->getDoctrine()->getManager();
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
                if( $movie->getFileposter()!=null ){
                    $movie->setType("movie");
                    $movie->setRating("0");
                    if( $movie->getFileposter()!=null){
                        $media= new Media();
                        $media->setFile($movie->getFileposter());
                        $media->upload($this->getParameter('files_directory'));
                        $em->persist($media);
                        $em->flush();
                        $movie->setPoster($media);
                    }
                    $em->persist($movie);
                    $em->flush();
                    $this->addFlash('success', 'Operation has been done successfully');
                    return $this->redirect($this->generateUrl('app_admin_movie_index'));
                }else{
                    $error = new FormError("Required image file");
                    $form->get('fileposter')->addError($error);
                }
       }
       return $this->render("Admin/Movie/add.html.twig",array("form"=>$form->createView()));
    }




    public function delete($id,Request $request) : Response
    {
        $em=$this->getDoctrine()->getManager();

        $movie = $em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"type"=>"movie"));
        if($movie==null){
            throw new NotFoundHttpException("Page not found");
        }


            $items = $em->getRepository("App\Admin\Entity\Item")->findBy(array("poster"=>$movie));

            foreach ($items as $key => $item) {

                $em->remove($item);
                $em->flush();
            }

            $slide = $em->getRepository("App\Admin\Entity\Slide")->findOneBy(array("poster"=>$movie));
            $slide = null;
            if ($slide!=null) {
                $media_slide = $slide->getMedia();
                $em->remove($slide);
                $em->flush();

                if ($media_slide != null) {
                    $media_slide->delete($this->getParameter('files_directory'));
                    $em->remove($media_slide);
                    $em->flush();
                }
                $slides = $em->getRepository('App\Admin\Entity\Slide')->findBy(array(), array("position" => "asc"));

                $p = 1;
                foreach ($slides as $key => $value) {
                    $value->setPosition($p);
                    $p++;
                }
                $em->flush();
            }
            foreach ($movie->getTorrents() as $key => $torrent) {

                $em->remove($torrent);
                $em->flush();
            }
            foreach ($movie->getSubtitles() as $key => $subtitle) {
                $media_subtitle = $subtitle->getMedia();
                
                $em->remove($subtitle);
                $em->flush();

                if ($media_subtitle!=null) {
                    $media_subtitle->delete($this->getParameter('files_directory'));
                    $em->remove($media_subtitle);
                    $em->flush();
                }
            }



            $media_poster = $movie->getPoster();

            $em->remove($movie);
            $em->flush();


            if ($media_poster!=null) {
                $media_poster->delete($this->getParameter('files_directory'));
                $em->remove($media_poster);
                $em->flush();
            }



           $this->addFlash('success', 'Operation has been done successfully');
           return $this->redirect($this->generateUrl('app_admin_movie_index'));
        
    }

    public function subtitles(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $movie=$em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"type"=>"movie"));
        if ($movie==null) {
            throw new NotFoundHttpException("Page not found");
        }
        return $this->render("Admin/Movie/subtitles.html.twig",array("movie"=>$movie));
    }
    
    public function cast(Request $request,$id,PaginatorInterface $paginator) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $movie=$em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"type"=>"movie"));
        if ($movie==null) {
            throw new NotFoundHttpException("Page not found");
        }


        $role = new Role();
        $role_form = $this->createForm(RoleType::class,$role);
        $role_form->handleRequest($request);
        if ($role_form->isSubmitted() && $role_form->isValid()) {
                $max=0;
                $roles=$em->getRepository('App\Admin\Entity\Role')->findBy(array("poster"=>$movie));
                foreach ($roles as $key => $value) {
                    if ($value->getPosition()>$max) {
                        $max=$value->getPosition();
                    }
                }
                $role->setPosition($max+1);
                $role->setPoster($movie);
                $em->persist($role);
                $em->flush();  
                $role = new Role();
                $role_form = $this->createForm(RoleType::class,$role);
        }

        $dql        = "SELECT r FROM App\Admin\Entity\Role r  WHERE r.poster = ". $id ." ORDER BY r.position desc ";
        $query      = $em->createQuery($dql);
        $pagination = $paginator->paginate(
        $query,
        $request->query->getInt('page', 1),
            12
        );


        return $this->render("Admin/Movie/cast.html.twig",array("role_form"=>$role_form->createView(),'pagination' => $pagination,"movie"=>$movie));
    }

    public function torrents(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $movie=$em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"type"=>"movie"));
        if ($movie==null) {
            throw new NotFoundHttpException("Page not found");
        }

        return $this->render("Admin/Movie/torrents.html.twig",array("movie"=>$movie));
    }
    
    public function comments(Request $request,$id,PaginatorInterface $paginator) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $movie=$em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"type"=>"movie"));
        if ($movie==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $em= $this->getDoctrine()->getManager();
        $dql        = "SELECT c FROM App\Admin\Entity\Comment c  WHERE c.poster = ". $id ." ORDER BY c.created desc ";
        $query      = $em->createQuery($dql);
        $pagination = $paginator->paginate(
        $query,
        $request->query->getInt('page', 1),
            10
        );
       $count=$em->getRepository('App\Admin\Entity\Comment')->countByPoster($movie->getId());
        
        return $this->render('Admin/Movie/comments.html.twig',
            array(
                'pagination' => $pagination,
                'movie' => $movie,
                'count' => $count,
            )
        );
    }

    public function ratings(Request $request,$id,PaginatorInterface $paginator) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $movie=$em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"type"=>"movie"));
        if ($movie==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $rates_1 = $em->getRepository('App\Admin\Entity\Rating')->findBy(array("poster"=>$movie,"value"=>1));
        $rates_2 = $em->getRepository('App\Admin\Entity\Rating')->findBy(array("poster"=>$movie,"value"=>2));
        $rates_3 = $em->getRepository('App\Admin\Entity\Rating')->findBy(array("poster"=>$movie,"value"=>3));
        $rates_4 = $em->getRepository('App\Admin\Entity\Rating')->findBy(array("poster"=>$movie,"value"=>4));
        $rates_5 = $em->getRepository('App\Admin\Entity\Rating')->findBy(array("poster"=>$movie,"value"=>5));
        $rates = $em->getRepository('App\Admin\Entity\Rating')->findBy(array("poster"=>$movie));


        $ratings["rate_1"]=sizeof($rates_1);
        $ratings["rate_2"]=sizeof($rates_2);
        $ratings["rate_3"]=sizeof($rates_3);
        $ratings["rate_4"]=sizeof($rates_4);
        $ratings["rate_5"]=sizeof($rates_5);


        $t = sizeof($rates_1) + sizeof($rates_2) +sizeof($rates_3)+ sizeof($rates_4) + sizeof($rates_5);
        if ($t == 0) {
            $t=1;
        }
        $values["rate_1"]=(sizeof($rates_1)*100)/$t;
        $values["rate_2"]=(sizeof($rates_2)*100)/$t;
        $values["rate_3"]=(sizeof($rates_3)*100)/$t;
        $values["rate_4"]=(sizeof($rates_4)*100)/$t;
        $values["rate_5"]=(sizeof($rates_5)*100)/$t;

        $total=0;
        $count=0;
        foreach ($rates as $key => $r) {
           $total+=$r->getValue();
           $count++;
        }
        $v=0;
        if ($count != 0) {
            $v=$total/$count;
        }
        $rating=$v;
        $count=$em->getRepository('App\Admin\Entity\Rating')->countByPoster($movie->getId());
        
        $em= $this->getDoctrine()->getManager();
        $dql        = "SELECT c FROM App\Admin\Entity\Rating c  WHERE c.poster = ". $id ." ORDER BY c.created desc ";
        $query      = $em->createQuery($dql);
        $pagination = $paginator->paginate(
        $query,
        $request->query->getInt('page', 1),
            10
        );
        return $this->render("Admin/Movie/ratings.html.twig", array("pagination"=>$pagination,"count"=>$count,"rating"=>$rating,"ratings"=>$ratings,"values"=>$values,"movie" => $movie));

    }
    
    public function edit(Request $request,$id) : Response
    {
        $em=$this->getDoctrine()->getManager();
        $movie=$em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"type"=>"movie"));
        if ($movie==null) {
            throw new NotFoundHttpException("Page not found");
        }
        $form = $this->createForm(MovieType::class,$movie);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            if( $movie->getFileposter()!=null ){
                $media_poster= new Media();
                $media_poster_old=$movie->getPoster();
                $media_poster->setFile($movie->getFileposter());
                $media_poster->upload($this->getParameter('files_directory'));
                $em->persist($media_poster);
                $em->flush();
                
                $movie->setPoster($media_poster);
                $media_poster_old->delete($this->getParameter('files_directory'));
                $em->remove($media_poster_old);
                $em->flush();
            }
            $em->flush();
            $this->addFlash('success', 'Operation has been done successfully');
            return $this->redirect($this->generateUrl('app_admin_movie_index'));
        }
        return $this->render("Admin/Movie/edit.html.twig",array("movie"=>$movie,"form"=>$form->createView()));
    }
    
    public function api_add_rate(Request $request,$token) : Response
    {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $user = $request->get("user");
        $poster = $request->get("poster");
        $key = $request->get("key");
        $value = $request->get("value");
        $feedback = $request->get("feedback");

        $em = $this->getDoctrine()->getManager();
        $poster_obj = $em->getRepository('App\Admin\Entity\Poster')->find($poster);
        $user_obj = $em->getRepository("App\Auth\Entity\User")->find($user);

        $code = "200";
        $message = "";
        $errors = array();
        if ($user_obj != null and $poster_obj != null) {
            if (sha1($user_obj->getPassword()) == $key) {
                $rate = $em->getRepository('App\Admin\Entity\Rating')->findOneBy(array("user" => $user_obj, "poster" => $poster_obj));
                if ($rate == null) {
                    $rate_obj = new Rating();
                    $rate_obj->setValue($value);
                    $rate_obj->setPoster($poster_obj);
                    $rate_obj->setReview($feedback);
                    $rate_obj->setUser($user_obj);
                    $em->persist($rate_obj);
                    $em->flush();
                    $message = "Your Ratting has been added";
                } else {
                    $rate->setValue($value);
                    $em->flush();
                    $message = "Your Ratting has been edit"; 
                }
                $rates = $em->getRepository('App\Admin\Entity\Rating')->findBy(array("poster" => $poster_obj));

                $total = 0;
                $count = 0;
                foreach ($rates as $key => $r) {
                    $total += $r->getValue();
                    $count++;
                }
                $v = 0;
                if ($count != 0) {
                    $v = $total / $count;
                }
                $v2 = number_format((float) $v, 1, '.', '');
                $errors[] = array("name" => "rate", "value" => $v2);
                
                $poster_obj->setRating($v2);
                $em->flush();
            }else {
                $code = "500";
                $message = "Sorry, your rate could not be added at this time";

            }
        } else {
            $code = "500";
            $message = "Sorry, your rate could not be added at this time";
        }
        $error = array(
            "code" => $code,
            "message" => $message,
            "values" => $errors,
        );
        $encoders = array(new XmlEncoder(), new JsonEncoder());
        $normalizers = array(new ObjectNormalizer());
        $serializer = new Serializer($normalizers, $encoders);
        $jsonContent = $serializer->serialize($error, 'json');
        return new Response($jsonContent);
    }
    public function share(Request $request, $id) : Response
    {
        $em = $this->getDoctrine()->getManager();
        $poster = $em->getRepository("App\Admin\Entity\Poster")->find($id);
        $setting = $em->getRepository("App\Admin\Entity\Settings")->findOneBy(array());
        if ($poster == null) {
            throw new NotFoundHttpException("Page not found");
        }
        return $this->render("Admin/Movie/share.html.twig", array("poster" => $poster, "setting" => $setting));
    }
    public function api_reviews($id,$token) : Response
    {
        if ($token!=$this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");  
        }
        $em=$this->getDoctrine()->getManager();

        $poster=$em->getRepository('App\Admin\Entity\Poster')->find($id);
        $reviews=array();
        if ($poster!=null) {
            $reviews=$em->getRepository('App\Admin\Entity\Rating')->findBy(array("poster"=>$poster));
        }

        return $this->render("Admin/Movie/api_reviews.html.php",
            array('reviews' => $reviews)
        );  
    }



    public function api_mylist(Request $request,CacheManager $imagineCacheManager, $token,$key,$id) : Response
    {
        if ($token != $this->getParameter('token_app')) {
            throw new NotFoundHttpException("Page not found");
        }
        $em = $this->getDoctrine()->getManager();

        $user = $em->getRepository("App\Auth\Entity\User")->findOneBy(array("id"=>$id));
        $nombre = 30;
        $page = 0;
        if($user){
            if ($user->isEnabled()) {
                if ($key==sha1($user->getPassword())) {
                    $repository = $em->getRepository('App\Admin\Entity\Item');

                    $repo_query = $repository->createQueryBuilder('i');

                    $repo_query->leftJoin('i.poster', 'p');
                    $repo_query->where($repo_query->expr()->isNotNull('i.poster'));
                    $repo_query->andWhere("p.enabled = true");
                    $repo_query->andWhere("i.user =".$user->getId());


                    $repo_query->addOrderBy('i.position', "desc");
                    $repo_query->addOrderBy('p.id', 'ASC');

                    $query =  $repo_query->getQuery(); 
                    $query->setFirstResult($nombre * $page);
                    $query->setMaxResults($nombre);
                    $items = $query->getResult();
                    $posters=array();
                    foreach ($items as $key => $item) {
                        $posters[]=$item->getPoster();
                    }
                    $posters_list =   $this->moviesToJson($posters,$imagineCacheManager);


                    $response = new Response();
                    $response->setContent(json_encode(
                        $posters_list
                    ));
                    $response->headers->set('Content-Type', 'application/json');
                    return $response;

                }
            }
        }
       return new Response("");
    }
    public function api_addlist(Request $request,$token): Response
    {

            $id =$request->request->get('id');
            $user =$request->request->get('user');
            $key =$request->request->get('key');
            if ($token != $this->getParameter('token_app')) {
                throw new NotFoundHttpException("Page not found");
            }
            $code = 500;
            $em=$this->getDoctrine()->getManager();
            $user_obj = $em->getRepository("App\Auth\Entity\User")->findOneBy(array("id"=>$user));

            if ($user_obj!=null){

                    $poster = $em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"enabled"=>true));
                    if ($poster !=null) {
                        $item = $em->getRepository("App\Admin\Entity\Item")->findOneBy(array("user"=>$user_obj,"poster" => $poster));
                        if ($item == null) {
                            
                            $last_item = $em->getRepository("App\Admin\Entity\Item")->findOneBy(array("user"=>$user_obj),array("position"=>"desc"));
                            $position=1;
                            if ($last_item!=null) {
                                $position=$last_item->getPosition()+1;
                            }
                            $code = 200;
                            $item = new Item();
                            $item->setPoster($poster);
                            $item->setUser($user_obj);
                            $item->setPosition($position);
                            $em->persist($item);
                            $em->flush();
                        }else{
                            $em->remove($item);
                            $em->flush();
                            $code = 202;
                        }
                    }
                

            }
        
        return new Response($code);
    } 
    public function api_checklist(Request $request,$token) : Response
    {
            $id =$request->request->get('id');
            $user =$request->request->get('user');
            $key =$request->request->get('key');
            if ($token != $this->getParameter('token_app')) {
                throw new NotFoundHttpException("Page not found");
            }
            $code = 500;
            $em=$this->getDoctrine()->getManager();
            $user_obj = $em->getRepository("App\Auth\Entity\User")->findOneBy(array("id"=>$user));

            if ($user_obj!=null){
                $poster = $em->getRepository("App\Admin\Entity\Poster")->findOneBy(array("id"=>$id,"enabled"=>true));
                if ($poster !=null) {
                    $item = $em->getRepository("App\Admin\Entity\Item")->findOneBy(array("user"=>$user_obj,"poster" => $poster));
                    if ($item == null) {
                        $code = 202;
                    }else{
                        $code = 200;
                    }
                }

            }
        
        return new Response($code);
    } 

}
?>