<?php
namespace App\Admin\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Admin\Form\ChangePasswordType;
use Symfony\Component\Form\FormError;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use App\Admin\Form\EditProfileType;
use App\Media\Entity\Media;
class ProfileController  extends AbstractController
{
    public function change_password(Request $request,UserPasswordEncoderInterface $passwordEncoder,UserPasswordHasherInterface $userPasswordHasher): Response
    {


 		// The token is valid; allow the user to change their password.
        $form = $this->createForm(ChangePasswordType::class);
        $form->handleRequest($request);
        $entityManager = $this->getDoctrine()->getManager();

        if ($form->isSubmitted() && $form->isValid()) {

			if($passwordEncoder->isPasswordValid($this->getUser(), $form->get('oldPassword')->getData())) {

	            $encodedPassword = $userPasswordHasher->hashPassword(
	                $this->getUser(),
	                $form->get('plainPassword')->getData()
	            );

	            $this->getUser()->setPassword($encodedPassword);
	            $entityManager->flush();
		        $this->addFlash('success','Your password has been changed successfully !');
        	 }else{
        	 	$form->get('oldPassword')->addError(new FormError('old password incorrect'));
        	 }


        }

        return $this->render('Admin/Profile/change_password.html.twig', [
            'form' => $form->createView(),
        ]);

        return $this->render("Admin/Profile/change_password.html.twig");
    }
    public function edit_profile(Request $request): Response
    {
    	$em = $this->getDoctrine()->getManager();
        $id = $this->getUser()->getId();
        $user = $em->getRepository("App\Auth\Entity\User")->find($id);

        $form = $this->createForm(EditProfileType::class,["name"=>$user->getName(),"file"=>null]);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            if( $form->get('file')->getData()!=null ){
                $media= new Media();
                $media_old=$user->getMedia();
                $media->setFile($form->get('file')->getData());
                $media->upload($this->getParameter('files_directory'));
                $em->persist($media);
                $em->flush();
                $media->setFile(null);
                $user->setMedia($media);
                if ($media_old != null) {
	 				$media_old->delete($this->getParameter('files_directory'));
	                $em->remove($media_old);
	                $em->flush();
                }
            }
            $user->setName($form->get('name')->getData());
            $em->flush();
		    $this->addFlash('success','Your profile has been updated successfully !');
        }
        return $this->render("Admin/Profile/edit_profile.html.twig",["form"=>$form->createView()]);
    }
}
?>