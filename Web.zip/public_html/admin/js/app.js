(function($) {
  var themovieddUrl = "https://api.themoviedb.org/3/";
  var postersList;

  $("body").on("click",".alert button.close",function() {
      $(this).parent(".alert").slideUp();
  });
   setTimeout( function(){
        $(".alert").slideUp();
  },5000);


    $("body").on("change",".image-input",function() {
      var label = $(this).prev().find("span.uploader-label");
      var icon = $(this).prev().find("span.uploader-icon");
      var preview = $(this).prev().prev();
      var uploader = $(this).prev();

      readURL(this,uploader,label,icon,preview);
    });
  function readURL(input,uploader,label,icon,preview) {

    if (input.files && input.files[0]) {
      var countFiles = input.files.length;
      var imgPath = input.value;
      var extn = imgPath.substring(imgPath.lastIndexOf('.') + 1).toLowerCase();
        var reader = new FileReader();
        reader.onload = function(e) {
          $(label).text(imgPath);
          $(icon).html("file_download_done");
          $(uploader).addClass("active")
          if (extn == "png" || extn == "jpg" || extn == "jpeg" ) {
            $(preview).attr('src',e.target.result);
          }
        }
        reader.readAsDataURL(input.files[0]);
     
    }
  }
  $("body").on("change","#torrent_type",function() {
    if ($("#torrent_type").val() == 2) {
      $("#torrent_url").parent().hide();
      $("#torrent_file").parent().show();
    } else {
      $("#torrent_url").parent().show();
      $("#torrent_file").parent().hide();
    }
  });
$("body").on("click","#close_search",function() {
    $("#div1").hide();
  })
 $("body").on("click","#search-imdb",function() {

    var value = $("#input-imdb").val();
    var type = $("#type-imdb").val();
    if (type == "title") {
      var d = {
        "api_key": themoviedb_key,
        "query": value,
        "language": language
      };
      $.ajax({
        data: d,
        url: themovieddUrl + "search/movie",
        success: function(result) {
          if (result.total_results == 0) {
            alert("No Movies Founded");
          } else {
            var List = "";
            postersList = new Array();
            for (var i = 0; i < result.results.length; i++) {
              postersList[i] = result.results[i];
              List += "<div  id='" + i + "' alt=" + result.results[i].id + " class='poster-search select_serie_movie'><img src='https://image.tmdb.org/t/p/w400" + result.results[i].poster_path + "'/><span>" + result.results[i].original_title + "</span><div>" + result.results[i].release_date + "</div></div>";
            }
            $("#result_search").html(List);
            $("#div1").show();
          }
        }
      });
    } else {
      var d = {
        "api_key": themoviedb_key,
        "language": language,
        "external_source": "imdb_id"
      };
      $.ajax({
        data: d,
        url: themovieddUrl + "find/" + value,
        success: function(result) {
          if (result.movie_results.length == 0) {
            alert("No Movies Founded");
          } else {
            var List = "";
            postersList = new Array();
            for (var i = 0; i < result.movie_results.length; i++) {
              postersList[i] = result.movie_results[i];
              List += "<div  id='" + i + "' alt=" + result.movie_results[i].id + " class='poster-search select_serie_movie'><img src='https://image.tmdb.org/t/p/w400" + result.movie_results[i].poster_path + "'/><span>" + result.movie_results[i].original_title + "</span><div>" + result.movie_results[i].release_date + "</div></div>";
            }
            $("#result_search").html(List);
            $("#div1").show();
          }
        }
      });
    }
  });
   $(document).on("click", ".select_serie_movie", function() {
    SelectMovie($(this).attr("id"));
  });
  function SelectMovie(index) {
    $(".poster-infos").show();
    $("#title-poster").html(postersList[index].original_title);
    $("#date-poster").html(postersList[index].release_date);
    $("#overview-poster").html(postersList[index].overview);
    $("#rating-poster").html(postersList[index].vote_average);

    $("#image-poster").attr("src", "https://image.tmdb.org/t/p/w500" + postersList[index].poster_path);
    $("#div1").hide();
    $("#result_search").html("");
    $("#form_id").val(postersList[index].id);

  }

  $("#search-imdb-tv").on("click",function() {
    var value = $("#input-imdb").val();
    var type = $("#type-imdb").val();
    if (type == "title") {

      var d = {
        "api_key": themoviedb_key,
        "query": value,
        "language": language
      };
      $.ajax({
        data: d,
        url: themovieddUrl + "search/tv",
        success: function(result) {
          if (result.total_results == 0) {
            alert("No Movies Founded");
          } else {
            var List = "";
            postersList = new Array();
            for (var i = 0; i < result.results.length; i++) {
              postersList[i] = result.results[i];
              List += "<div id='" + i + "'  alt=" + result.results[i].id + " class='poster-search select_serie_tv'><img src='https://image.tmdb.org/t/p/w400" + result.results[i].poster_path + "'/><span>" + result.results[i].original_name + "</span><div>" + result.results[i].first_air_date + "</div></div>";
            }
            $("#result_search").html(List);
            $("#div1").show();
          }
        }
      });
    } else {
      var d = {
        "api_key": themoviedb_key,
        "language": language,
        "external_source": "imdb_id"
      };
      $.ajax({
        data: d,
        url: themovieddUrl + "find/" + value,
        success: function(result) {
          if (result.tv_results.length == 0) {
            alert("No Movies Founded");
          } else {
            var List = "";
            postersList = new Array();
            for (var i = 0; i < result.tv_results.length; i++) {
              postersList[i] = result.tv_results[i];
              List += "<div  id='" + i + "'  alt=" + result.tv_results[i].id + " class='poster-search select_serie_tv'><img src='https://image.tmdb.org/t/p/w400" + result.tv_results[i].poster_path + "'/><span>" + result.tv_results[i].original_name + "</span><div>" + result.tv_results[i].first_air_date + "</div></div>";
            }
            $("#result_search").html(List);
            $("#div1").show();
          }
        }
      });
    }
  });

    $(document).on("click", ".select_serie_tv", function() {
    SelectSerieTv($(this).attr("id"));
  });

  function SelectSerieTv(index) {
    $(".poster-infos").show();
    $("#title-poster").html(postersList[index].original_name);
    $("#date-poster").html(postersList[index].first_air_date);
    $("#overview-poster").html(postersList[index].overview);
    $("#rating-poster").html(postersList[index].vote_average);

    $("#image-poster").attr("src", "https://image.tmdb.org/t/p/w500" + postersList[index].poster_path);
    $("#div1").hide();
    $("#result_search").html("");
    $("#form_id").val(postersList[index].id);

  }
  $(document).on("change","#form_torrents_x",function() {
    if(this.checked){

     $('input[name="form[torrents][]"]').prop( "checked", true );
    }else{
           $('input[name="form[torrents][]"]').prop( "checked", false );

    }
  });
  $("#import_movie").on("click",function() {
    $(this).html("<span class='material-icons animation_icon'>motion_photos_on</span> Importing...");
  });
})(jQuery);